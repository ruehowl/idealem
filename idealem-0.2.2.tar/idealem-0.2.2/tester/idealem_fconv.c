/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * last updated on Mon Feb 29 15:42:06 PST 2016
 *
 */
//
// idealem_text2bin.c
// conversion from text input to text output
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define VERSION "IDEALEM text2bin v0.1"
#define DATE    "Wed Mar  9 09:34:00 PST 2016"
#define COPYRIGHT "Copyright (c) 2016 Lawrence Berkeley National Laboratory"

int read_double(void *ptr, size_t nitems, FILE *stream, int max_input_read) {
    int i;
    char line[max_input_read];
    for (i=0; i<nitems; i++) {
        if (!fgets(line, sizeof(line), stream)) break;
        *((double *)ptr + i) = atof(line);
    }
    return i;
}

int read_double_bin(void *ptr, size_t nitems, FILE *stream, int max_input_read) {
	int count = fread((double *)ptr, sizeof(double), nitems, stream);
    return count;
}

int write_double(const void *ptr, size_t nitems, FILE *stream, int precision) {
    int i;
    for (i=0; i<nitems; i++) {
        if (!fprintf(stream, "%.*f\n", precision, *((double *)ptr + i)))
            break;
    }
    return i;
}

int write_double_bin(const void *ptr, size_t nitems, FILE *stream, int precision) {
    int count = fwrite((double *)ptr, sizeof(double), nitems, stream);
    return count;
}

//  
//  DECODING
//  statistical data restore from the encoded data for testing purpose
int idealem_text2bin(const char* inputfile_path, const char* outputfile_path, int max_input_read) {
// const char* inputfile_path
// const char* outputfile_path
// int max_input_read

	FILE* inputfile_d;
    FILE* outputfile_d;
    //char line[max_input_read];
    char line[1024];
	double myvalue;
	
	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	inputfile_d = fopen(inputfile_path, "r" );
	if (!inputfile_d) {
		printf("couldn't open input file from encoded data %s\n", inputfile_path);
		exit(1);
	}

	if ((outputfile_path == NULL) || (strlen(outputfile_path) == 0)) {
		strcpy((char*)outputfile_path, inputfile_path);
		strcat((char*)outputfile_path, ".t2b.data");
	}
	outputfile_d = fopen(outputfile_path, "wb" );
	if (!outputfile_d) {
		printf("couldn't open output file %s\n", outputfile_path);
		exit(1);
	}

	printf("convering...%s\n", inputfile_path);
    while (fgets(line, sizeof(line), inputfile_d)) {
    	myvalue = atof(line);
	    fwrite(&myvalue, sizeof(double), 1, outputfile_d);
	}

    fclose(inputfile_d);
    fclose(outputfile_d);

	return 0;
}


const char usage[] = "usage:  idealem_t2b [-options ...]\n\n\
where options include:\n\
  -h/help\n\
  -i/in inputfile\n\
  -maxread/read int [default=1024]\n\
  -o/out [outputfile, default=./inputfile.b2t.data]\n\
  -v/version\n\n";

int main(int argc, const char * argv[]) {
    char inputfile_path[1024];
    char outputfile_dec_path[1024];
    int max_input_read=1024;
	
    for (int i=1 ; i < argc; i++) {
        if (argv[i][0] != '-') {
            printf("%s : error, unknown argument %s\n%s",
                        argv[0],argv[i],usage);
            exit(1);
        }
        else {
            switch (argv[i][1]) {
                case 'h' :
                    if (!strcmp(argv[i], "-help") ||
						!strcmp(argv[i], "-h")) {
                        fprintf(stderr,"%s [options]\n",argv[0]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'v':
                    fprintf(stderr,"\n%s\n",VERSION);
                    fprintf(stderr,"%s\n",COPYRIGHT);
                    fprintf(stderr,"%s\n\n",DATE);
                    exit(0);
                    break;
	            case 'i' :
                    if (!strcmp(argv[i], "-in") ||
						!strcmp(argv[i], "-i")) {
                        strcpy(inputfile_path, argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'm' :
                    if (!strcmp(argv[i], "-maxread") || 
						!strcmp(argv[i], "-read")) {
                        max_input_read=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'o':
                    if (!strcmp(argv[i], "-out") ||
						!strcmp(argv[i], "-o")) {
                        i++;
                        if ((i < argc) && (argv[i][0] != '-')) {
							strcpy(outputfile_dec_path, argv[i]);
                            strcat(outputfile_dec_path, ".b2t.data");
                        }
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                default :
                    fprintf(stderr,"%s [options]\n",argv[i]);
                    fprintf(stderr,"%s",usage);
                    exit(1);
                    break;
            }
        }
    }
	idealem_text2bin(inputfile_path, outputfile_dec_path, max_input_read);
    return 0;
}
	
