'''
/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM) Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * last update on Mon Feb 29 15:47:58 PST 2016
 *
 */

python ./tester/data_simple_plots.py -h
usage: data_simple_plots.py [-h] [-b BLOCKSIZE] [-c CAPTION_TEXT] -o
                            ORG_FILENAME -e ENC_FILENAME -d DEC_FILENAME
                            [-t PLOT_TITLE] [--allinone] [--allindep] [-l]
                            [--save OUTPLOT_NAME]

IDEALEM result testing program

optional arguments:
  -h, --help            show this help message and exit
  -b BLOCKSIZE, --blocksize BLOCKSIZE
                        LEM block size
  -c CAPTION_TEXT, --caption CAPTION_TEXT
                        additional messages on the plot
  -o ORG_FILENAME, --original ORG_FILENAME
                        original data file path to plot
  -e ENC_FILENAME, --encoded ENC_FILENAME
                        encoded data file path to plot
  -d DEC_FILENAME, --decoded DEC_FILENAME
                        decoded data file path to plot
  -t PLOT_TITLE, --title PLOT_TITLE
                        plot title
  -l, --l2norm          plot of differences and L2-norm calculation
  -r, --results         additional result messages on the plot
  --allinone            one plot for all data
  --allindep            three plots for data
  --save OUTPLOT_NAME   output file name for the plot

python data_simple_plots.py -b 16 \
-o /Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1.txt \
-e /Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1.txt.o.data \
-d /Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1.txt.o.data.o.data \
-t "LEM results" \
--save "dataplot2.png" \
-l --allindep
'''
import sys, getopt, os
import operator
import time
import subprocess
#import math
import matplotlib.pyplot as plt
import numpy as npy
import scipy as spy
#import sympy as sym
#import numbers      # for Real numbers
#import array        # for Array handling for plots
#from sympy.abc import x     # math symbol x
#from sympy import log, sin, cos, tan, exp, pi, I, oo, zoo, S, sympify
#from scipy import integrate, stats # integration to compare the answer, KS statistics
from scipy import stats # KS statistics
from numpy import linalg  # L2norm
import fileinput
import argparse

b2tcmd = "./idealem_b2t"
blocksize=16
org_filename = "/Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1e1.txt"
enc_filename = "/Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1e1.txt.o.data"
dec_filename = "/Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1e1.txt.o.data.o.data"
plot_title = "IDEALEM results"
xaxis_title = "Time Sequences"
yaxis_title = "Values"
outplot_name = "lem_result.png"
l2norm_flag = False
allinone_flag = False
allindep_flag = False
result_flag = False
timing_flag = False
nodisplay_flag = False

# command line options
parser = argparse.ArgumentParser(description='IDEALEM result testing program')
parser.add_argument("-b", "--blocksize", type=int, dest="blocksize", default=16, help="LEM block size")
parser.add_argument("-c", "--caption", action="store", dest="caption_text", required=False, help="additional messages on the plot")
parser.add_argument("-o", "--original", action="store", dest="org_filename", required=True, help="original data file path to plot")
parser.add_argument("-e", "--encoded", action="store", dest="enc_filename", required=True, help="encoded/reduced data file path to plot")
parser.add_argument("-d", "--decoded", action="store", dest="dec_filename", required=True, help="decoded/reconstructed data file path to plot")
parser.add_argument("-l", "--l2norm", action="store_true", dest="l2norm_flag", required=False, help="plot of differences and L2-norm calculation")
parser.add_argument("-r", "--results", action="store_true", dest="result_flag", required=False, help="additional result messages on the plot")
parser.add_argument("-t", "--title", action="store", dest="plot_title", required=False, help="plot title")
parser.add_argument("-x", "--xaxis", action="store", dest="xaxis_title", required=False, help="X axis label on the plot")
parser.add_argument("-y", "--yaxis", action="store", dest="yaxis_title", required=False, help="Y axis label on the plot")
parser.add_argument("--allinone", action="store_true", dest="allinone_flag", required=False, help="one plot for all data")
parser.add_argument("--allindep", action="store_true", dest="allindep_flag", required=False, help="three plots for data")
parser.add_argument("--timing", action="store_true", dest="timing_flag", required=False, help="timeing measurements")
parser.add_argument("--save", action="store", dest="outplot_name", required=False, help="output file name for the plot")
parser.add_argument("--nodisplay", action="store_true", dest="nodisplay_flag", required=False, help="Option not to display plots")

# comment out below for general use
#args = parser.parse_args(['-b', '16', '--timing', '--nodisplay', '-l', '--allindep', '--save', 'dataplot2.png',
#args = parser.parse_args(['-b', '16', '--timing', '--nodisplay', '--allindep', '--save', 'dataplot2.png',
args = parser.parse_args(['-b', '16', '--timing', '--allindep', '-l', '--save', 'dataplot2.png',
    '-o', '/Users/asim/Desktop/idealem/testdata4e5b1.txt', 
    '-e', '/Users/asim/Desktop/idealem/testdata4e5b1.txt.o.data', 
    '-d', '/Users/asim/Desktop/idealem/testdata4e5b1.txt.o.data.o.data'])
#    '-o', '/Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1e2.txt', 
#    '-e', '/Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1e2.txt.o.data', 
#    '-d', '/Users/asim/Documents/codeforge/idealem/trunk/samples/testdata1e2.txt.o.data.o.data'])
#args = parser.parse_args()     # uncomment this line for general use

if (args.blocksize): 
    blocksize = args.blocksize
org_filename = args.org_filename
enc_filename = args.enc_filename
dec_filename = args.dec_filename
if (args.l2norm_flag): 
    l2norm_flag = args.l2norm_flag
if (args.allinone_flag):
    allinone_flag = args.allinone_flag
if (args.allindep_flag) :
    allindep_flag = args.allindep_flag
if (args.result_flag) :
    result_flag = args.result_flag
if (args.timing_flag) :
    timing_flag = args.timing_flag
if (args.nodisplay_flag) :
    nodisplay_flag = args.nodisplay_flag

org_list = []
encode_list = []
hitcount_list = []
encode_index = []
decode_list = []
mtime_start = 0.0
mtime_end = 0.0

print "Reading original data..."
if (timing_flag) :
    readingtime_start = time.time()
for line in fileinput.input([org_filename]):
    parsed = line.split()
    org_list.append(float(parsed[0]))
if (timing_flag) :
    readingtime_end = time.time()
    print "Reading original data took ", readingtime_end - readingtime_start

#myx = npy.arange(0, len(org_list), 1)
myx = range(0, len(org_list), 1)

print "Converting encoded binary data..."
b2toptions = "-i " + enc_filename  # additional -history 3
b2tcmdoutput = subprocess.check_output([b2tcmd,'-i',enc_filename])
enc_filename = enc_filename + ".b2t.data"

print "Reading reduced data..."
blockcount=0
hitindex=0
fullsize = len(myx)
if (timing_flag) :
    readingtime_start = time.time()
for line in fileinput.input([enc_filename]):
    parsed = line.split()
    if (blockcount < blocksize):
        encode_list.append(float(parsed[0]))
        blockcount += 1
    else:
        myhit = int(parsed[0])
        hitcount_list.append(myhit)
        blockcount=0
        startindex = hitindex
        endindex = startindex + blocksize
        if (endindex > fullsize):
            print "original data index < encode/reduced generated index = ", fullsize, " < ", endindex
            endindex = fullsize
        #encode_index = encode_index + myx[startindex:endindex]
        encode_index.extend(myx[startindex:endindex])
        hitindex = endindex + (myhit*blocksize)
        

if (timing_flag) :
    readingtime_end = time.time()
    print "Reading reduced data took ", readingtime_end - readingtime_start
'''
if (timing_flag) :
    readingtime_start = time.time()
print "Reading hitcount list ", len(hitcount_list) 
for i in range(len(hitcount_list)):
    startindex = hitindex
    endindex = startindex + blocksize
    if (endindex > fullsize):
        print "original data index < encode/reduced generated index = ", fullsize, " < ", endindex
        endindex = fullsize
    encode_index.extend(myx[startindex:endindex])
    hitindex = endindex + (hitcount_list[i]*blocksize)
if (timing_flag) :
    readingtime_end = time.time()
    print "Calculating hit index took ", readingtime_end - readingtime_start
'''

#sys.exit()

hittotal = sum(hitcount_list)

print "Reading reconstructed data..."
dec_count = 0
if (timing_flag) :
    readingtime_start = time.time()
for line in fileinput.input([dec_filename]):
    parsed = line.split()
    decode_list.append(float(parsed[0]))
    dec_count += 1
    if (dec_count >= len(org_list)):
        break
if (timing_flag) :
    readingtime_end = time.time()
    print "Reading reconstructed data took ", readingtime_end - readingtime_start

org_file_info = os.stat(org_filename)
enc_file_info = os.stat(enc_filename)

print "block window size=", blocksize
print "original filename=", org_filename
print "encoded/reduced data filename=", enc_filename
print "decoded/reconstructed data filename=", dec_filename

bigcaption = "original data length=" + str(len(org_list)) + ",  " + \
        "encoded/reduced data length=" + str(len(encode_list)) + "\n" + \
        "number of unique blocks=" + str(len(hitcount_list)) + ",  " + \
        "decoded/reconstructed data length=" + str(len(decode_list)) + "\n" + \
        "data reduction ratio in data records=" +  str(float(len(org_list))/float(len(encode_list))) + "\n" + \
        "data reduction ratio in total records=" + str(float(len(org_list))/float((len(encode_list)+len(hitcount_list)))) + "\n" + \
        "data reduction ratio in byte size=" + str(float(org_file_info.st_size)/float(enc_file_info.st_size))

print "original data length=",len(org_list)
print "encoded/reduced data length=", len(encode_list)
print "decoded/reconstructed data length=", len(decode_list)
print "number of unique blocks=", len(hitcount_list)
print "number of redundant blocks=", hittotal
print "data reduction ratio in data records=", float(len(org_list))/float(len(encode_list))
print "data reduction ratio in total records=", float(len(org_list))/float((len(encode_list)+len(hitcount_list)))
print "data reduction ratio in byte size=", float(org_file_info.st_size)/float(enc_file_info.st_size)

#myx = npy.arange(0, len(hitcount_list), 1)
#for i in range(len(core_list)):
#    print "i=", encode_list[i], " ", decode_list[i]
#plt.scatter(myx, hitcount_list, color="green", label="Original")

numplots=2
if (allinone_flag) :
    numplots = 1
    l2norm_flag=False
    fplot, plots = plt.subplots(numplots, sharex=True, figsize=(11, 8))
    if (result_flag) :
        plt.subplots_adjust(bottom=0.16)
elif (l2norm_flag) or (allindep_flag) :
    numplots = 3
    if (allindep_flag):
        l2norm_flag=False
    fplot, plots = plt.subplots(numplots, sharex=True, figsize=(11, 8))
    if (result_flag) :
        plt.subplots_adjust(bottom=0.18)
else :
    numplots=2
    fplot, plots = plt.subplots(numplots, sharex=True, figsize=(11, 8))
    if (result_flag) :
        plt.subplots_adjust(bottom=0.16)
    #plt.figure(figsize=(11, 11))

if (args.plot_title):
    print "plot title=", plot_title
    plot_title = args.plot_title
if (args.xaxis_title):
    print "X axis label=", xaxis_title
    xaxis_title = args.xaxis_title
if (args.yaxis_title):
    print "Y axis label=", yaxis_title
    yaxis_title = args.yaxis_title
if (args.caption_text):
    print "additional plot caption=", args.caption_text
    fig = ploto.figure()
    fig.text(.15,.85,args.caption_text)
plt.hold(True)

if (numplots == 1):
    plots.scatter(myx, org_list, s=11, marker='s', color="green", label="original data")
    plt.hold(True)
    plots.scatter(encode_index, encode_list, s=8, alpha=0.7, marker='o', color="blue", label="reduced data")
    plt.hold(True)
    plots.scatter(myx, decode_list, s=9, marker='.', alpha=0.3, color="red", label="reconstructed data")
    plots.legend(bbox_to_anchor=(0.75, 0.95), loc=2, fontsize=10)
    plt.hold(True)
elif (numplots == 2) or (l2norm_flag):
    plots[0].set_title(plot_title, fontsize=11)
    plots[0].scatter(myx, org_list, s=10, marker='o', color="green", label="original")
    plots[0].legend(bbox_to_anchor=(1.0, 1.0), loc=2, fontsize=8)
    plt.hold(True)
    plots[1].set_title("Reduced data vs. Reconstructed data", fontsize=11)
    plots[1].scatter(myx, decode_list, s=10, marker='s', alpha=0.5, color="red", label="reconstructed data")
    plt.hold(True)
    plots[1].scatter(encode_index, encode_list, s=11, marker='.', color="blue", label="reduced data")
    plots[1].legend(bbox_to_anchor=(1.0, 1.0), loc=2, fontsize=8)
    plt.hold(True)
elif (numplots == 3) or (allindep_flag):
    plots[0].set_title("Original data", fontsize=11)
    plots[0].scatter(myx, org_list, s=10, marker='o', color="green", label="original data")
    plt.hold(True)
    plots[1].set_title("Reduced data", fontsize=11)
    plots[1].scatter(encode_index, encode_list, s=10, marker='x', color="blue", label="reduced data")
    plt.hold(True)
    plots[2].set_title("Reconstructed data", fontsize=11)
    plots[2].scatter(myx, decode_list, s=10, marker='.', alpha=0.5, color="red", label="reconstructed data")
    plt.hold(True)

if (l2norm_flag) :
    print "Calculating L2norm..."
    adiff_list = []
    '''
    # For L2norm of the block average
    amean_list = []
    numblocks = len(decode_list)/blocksize
    for i in range(numblocks):
        adiff_mean = npy.mean(org_list[i*blocksize:(i+1)*blocksize]) - npy.mean(decode_list[i*blocksize:(i+1)*blocksize])
        adiff_list.append(adiff_mean)
        amean_mean = npy.mean(org_list[i*blocksize:(i+1)*blocksize])
        amean_list.append(amean_mean)
        plotl.scatter(myx[i*blocksize], adiff_mean, s=10, color="blue")
        plt.hold(True)
    '''
    if (timing_flag) :
        readingtime_start = time.time()
    adiff_list = map(operator.sub, org_list, decode_list[0:len(org_list)])
    plots[2].scatter(myx, adiff_list, s=10, color="blue")
    plots[2].set_title("Original vs. Reconstructed: differences", fontsize=11)
    l2norm_value = npy.linalg.norm(adiff_list, 2)
    l2normalpha_value = l2norm_value / npy.linalg.norm(org_list, 2)
    if (timeing_flag) :
        readingtime_end = time.time()
        print "Calculating L2norm took ", readingtime_end - readingtime_start
    '''
    # For L2norm of the block average
    plotl.set_title("Original vs. Reconstructed: difference of block averages", fontsize=11)
    l2normalpha_value = l2norm_value / npy.linalg.norm(amean_list, 2)
    print "L2norm of difference of block averages for original and reconstructed data=", l2norm_value
    bigcaption = bigcaption + "\n" + "L2norm of difference of block averages=" + str(l2norm_value) + \
               "   " + "L2norm(original-reconstructed) / L2norm(original)=" + str(l2normalpha_value)
    '''
    print "L2norm of differences for original and reconstructed data=", l2norm_value
    bigcaption = bigcaption + "\n" + "L2norm of differences =" + str(l2norm_value) + \
               "   " + "L2norm(original-decoded) / L2norm(original)=" + str(l2normalpha_value)
    print "L2norm(original-reconstructed) / L2norm(original)=", l2normalpha_value
    plt.hold(True)

if (result_flag) :
    plt.figtext(.1, .01, bigcaption, multialignment="left", fontsize=10)
plt.xlim(myx[0]-0.01*len(myx), myx[len(myx)-1]+0.01*len(myx))
plt.xlabel(xaxis_title)
plt.ylabel(yaxis_title)

if (args.outplot_name):
    outplot_name = args.outplot_name
    print "output plot filename=", outplot_name
    plt.savefig(outplot_name, dpi=150)

if (not nodisplay_flag) :
	plt.show()

