/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * last updated on Mon Feb 29 15:42:06 PST 2016
 *
 */
//
// idealem_bin2text.c
// binary input for encoded data and text output for python plots
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define VERSION "IDEALEM bin2text v0.1"
#define DATE    "Wed Mar  9 09:34:00 PST 2016"
#define COPYRIGHT "Copyright (c) 2016 Lawrence Berkeley National Laboratory"

int read_double_bin(void *ptr, size_t nitems, FILE *stream, int max_input_read) {
	int count = fread((double *)ptr, sizeof(double), nitems, stream);
    return count;
}

int read_hit_count_bin(void *ptr, size_t nitems, FILE *stream, int max_input_read) {
	int count = fread((unsigned char *)ptr, sizeof(unsigned char), 1, stream);
    return count;
}

int write_double(const void *ptr, size_t nitems, FILE *stream, int precision) {
    int i;
    for (i=0; i<nitems; i++) {
        if (!fprintf(stream, "%.*f\n", precision, *((double *)ptr + i)))
            break;
    }
    return i;
}

int write_hit_count(const void *ptr, size_t nitems, FILE *stream) {
    int i;
    for (i=0; i<nitems; i++) {
        if (!fprintf(stream, "%u\n", *((unsigned char *)ptr + i)))
            break;
    }
    return i;
}

//  
//  DECODING
//  statistical data restore from the encoded data for testing purpose
int idealem_bin2text(const char* inputfile_path, const char* outputfile_dec_path, int lemblklen, int max_input_read, int precision) {
// const char* inputfile_path
// const char* outputfile_dec_path
// int lemblklen
// int max_input_read
// int precision

	FILE* inputfile_d;
    FILE* outputfile_dec_d;
	//time_t tid;
	
    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen

	double* block_samples;  // sample block array
	unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits 
		// with previous buffer to be written to the output

	block_samples = (double*)alloca(sizeof(double)*lemblklen);
    
	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file from encoded data %s\n", inputfile_path);
		exit(1);
	}

	if ((outputfile_dec_path == NULL) || (strlen(outputfile_dec_path) == 0)) {
		strcpy((char*)outputfile_dec_path, inputfile_path);
		strcat((char*)outputfile_dec_path, ".b2t.data");
	}
	outputfile_dec_d = fopen(outputfile_dec_path, "w" );
	if (!outputfile_dec_d) {
		printf("couldn't open output file for decoded data %s\n", outputfile_dec_path);
		exit(1);
	}
	
	block_size = read_double_bin(block_samples, lemblklen, inputfile_d, max_input_read);
    while (block_size) {
		write_double(block_samples, lemblklen, outputfile_dec_d, precision);
			// read new CDF to fresh buffer until end of the stream
		read_hit_count_bin(&hitcntbyte, 1, inputfile_d, max_input_read);
		write_hit_count(&hitcntbyte, 1, outputfile_dec_d);		
		block_size = read_double_bin(block_samples, lemblklen, inputfile_d, max_input_read);
    }

    fclose(inputfile_d);
    fclose(outputfile_dec_d);

	return 0;
}


//  
//  DECODING with historical buffers
//  statistical data restore from the encoded data for testing purpose
int idealem_bin2text_with_history(const char* inputfile_path, const char* outputfile_dec_path, int lemblklen, int max_hit_count, int max_input_read, int precision, int bufferno) {
	// const char* inputfile_path
	// const char* outputfile_dec_path
	// int lemblklen
	// int max_hit_count
	// int max_input_read
	// int precision
	// int bufferno

	FILE* inputfile_d;

    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen
	int overwrite = 0;  // overwrite flag
    unsigned char partitionsidx;  // partitions index to be read from input file
    unsigned char partitionscnt = 0;  
		// partition cnt to keep track of, 
		// no longer increases when it reaches partitionsnum
	int partitionsnum = bufferno; // number of historical buffers, default=1
	
    FILE* outputfile_dec_d;
	//time_t tid;

	double* block_samples;  // sample block array
	unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits 
		// with previous buffer to be written to the output
	int i=0; // index for loop
	
	block_samples = (double*)alloca(sizeof(double)*lemblklen);
    hitcntbyte = 0; // counter to keep track of # of hits with previous buffer
    
	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file from encoded data %s\n", inputfile_path);
		exit(1);
	}
	
	if ((outputfile_dec_path == NULL) || (strlen(outputfile_dec_path) == 0)) {
		strcpy((char*)outputfile_dec_path, inputfile_path);
		strcat((char*)outputfile_dec_path, ".b2t.data");
	}
	outputfile_dec_d = fopen(outputfile_dec_path, "w" ); 
	if (!outputfile_dec_d) {
		printf("couldn't open output file for decoded data %s\n", outputfile_dec_path);
		exit(1);
	}
	

    while (1) {
		block_size = read_hit_count_bin(&partitionsidx, 1, inputfile_d, max_input_read);
		if ( !block_size ) {
			// printf("end of the input file\n");
			break;
		}
		//printf("hit count = %d\n", partitionsidx);
		write_hit_count(&partitionsidx, 1, outputfile_dec_d);	
		if (partitionscnt == partitionsnum) { // when partitions are fully populated
			if (overwrite) {
				// read new CDF from CDF FILE and overwrite existing partition
				read_double_bin(block_samples, lemblklen, inputfile_d, max_input_read);
				//for (i=0; i< lemblklen; i++) printf("block %.10f\n", block_samples[i]);
				write_double(block_samples, lemblklen, outputfile_dec_d, precision);
				overwrite = 0; // reset the flag
			}
			else if (partitionsidx == 0xFF) { // overwriting marker
				overwrite = 1;  // raise the flag
				continue; // and continue
			}
		}
		else if (partitionscnt == partitionsidx) { 
			// when partitions are not populated yet and encounters new partition
			// read new CDF from CDF FILE to fresh partition
			read_double_bin(block_samples, lemblklen, inputfile_d, max_input_read);
			//for (i=0; i< lemblklen; i++) printf("block %.10f\n", block_samples[i]);
			write_double(block_samples, lemblklen, outputfile_dec_d, precision);
			partitionscnt++;
		}
    }
	
	fclose(inputfile_d);
    fclose(outputfile_dec_d);
	
	return 0;
}

const char usage[] = "usage:  idealem_b2t [-options ...]\n\n\
where options include:\n\
  -h/help\n\
  -history [default=1]\n\
  -i/in inputfile\n\
  -maxhitcount/maxhit/maxcount int [default=255]\n\
  -maxread/read int [default=1024]\n\
  -n/blocklen/lemblklen int [default=16]\n\
  -o/out [outputfile, default=./inputfile.b2t.data]\n\
  -v/version\n\n";

int main(int argc, const char * argv[]) {
    char inputfile_path[1024];
    char outputfile_dec_path[1024];
    int lemblklen=16;
    int max_hit_count=255; 
        // maximum hit count before encoder send out index 
        // adjusting to smaller value can reduce the delay
    int max_input_read=1024;
    int precision=10; // floating point precision for writing into files
	int history_buffer=1;	// single stream, just one historical buffer
	
    for (int i=1 ; i < argc; i++) {
        if (argv[i][0] != '-') {
            printf("%s : error, unknown argument %s\n%s",
                        argv[0],argv[i],usage);
            exit(1);
        }
        else {
            switch (argv[i][1]) {
                case 'h' :
                    if (!strcmp(argv[i], "-help") ||
						!strcmp(argv[i], "-h")) {
                        fprintf(stderr,"%s [options]\n",argv[0]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    else if (!strcmp(argv[i], "-history")){
                        history_buffer=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'v':
                    fprintf(stderr,"\n%s\n",VERSION);
                    fprintf(stderr,"%s\n",COPYRIGHT);
                    fprintf(stderr,"%s\n\n",DATE);
                    exit(0);
                    break;
	            case 'b' :
                    if (!strcmp(argv[i], "-blocklen")){
                        lemblklen=atoi(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-buffer")){
                        history_buffer=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
	            case 'i' :
                    if (!strcmp(argv[i], "-in") ||
						!strcmp(argv[i], "-i")) {
                        strcpy(inputfile_path, argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
				case 'l':
					if (!strcmp(argv[i], "-lemblklen")) {
						lemblklen=atoi(argv[++i]);
					}
					else {
						fprintf(stderr,"%s [options]\n",argv[i]);
						fprintf(stderr,"%s",usage);
						exit(1);
					}
					break;
                case 'm' :
                    if (!strcmp(argv[i], "-maxhitcount") || 
						!strcmp(argv[i], "-maxhit") ||
						!strcmp(argv[i], "-maxcount")) {
                        max_hit_count=atoi(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-maxread") || 
						!strcmp(argv[i], "-read")) {
                        max_input_read=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'n' :
                    if (!strcmp(argv[i], "-n")) {
                        lemblklen=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'o':
                    if (!strcmp(argv[i], "-out") ||
						!strcmp(argv[i], "-o")) {
                        i++;
                        if ((i < argc) && (argv[i][0] != '-')) {
							strcpy(outputfile_dec_path, argv[i]);
                            strcat(outputfile_dec_path, ".b2t.data");
                        }
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'p' :
                    if (!strcmp(argv[i], "-precision") ||
						!strcmp(argv[i], "-p")) {
                        precision=atof(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                default :
                    fprintf(stderr,"%s [options]\n",argv[i]);
                    fprintf(stderr,"%s",usage);
                    exit(1);
                    break;
            }
        }
    }
	if (history_buffer > 1) {
		idealem_bin2text_with_history(inputfile_path, outputfile_dec_path, lemblklen, max_hit_count, max_input_read, precision, history_buffer);
	}
	else {
		idealem_bin2text(inputfile_path, outputfile_dec_path, lemblklen, max_input_read, precision);
	}
    return 0;
}
	
