/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)" Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * Last updated on Mon Feb 29 15:36:02 PST 2016
 *
 */

//
// idealem_rim.c
// LEM encoder/decoder reference implementation program for a single stream
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <idealem_common.h>
#include <idealem_util.h>
#include <idealem_file_stream.h>

#define VERSION "IDEALEM v0.2"
#define COPYRIGHT "Copyright (c) 2016 Lawrence Berkeley National Laboratory"

const char usage[] = "usage:  idealem_c [-options ...]\n\n\
where options include:\n\
  -h/help\n\
  -bin [default=false, sets bin for all -typeei -typeeo -typedi -typedo]\n\
  -debug [default=false]\n\
  -decode [default=false]\n\
  -decodeonly [default=false]\n\
  -delta [default=false]\n\
  -encode [default=false]\n\
  -history [default=1]\n\
  -i/in inputfile\n\
  -l/log [logfile, default=./idealem_log.txt]\n\
  -maxhitcount/maxhit/maxcount int [default=255]\n\
  -maxread/read int [default=1000]\n\
  -n/blocklen/lemblklen int [default=16]\n\
  -o/out [outputfile, default=./inputfile.o.data]\n\
  -range double double [(optional) minimum and maximum value of range when -delta or -residual is on]\n\
  -reltol float [0~1]\n\
  -residual [default=false]\n\
  -threshold/alpha float [default=0.05]\n\
  -typeei text/bin [encoding input type, default=text]\n\
  -typeeo text/bin [encoding output type, default=bin]\n\
  -typedi text/bin [decoding input type, default=bin]\n\
  -typedo text/bin [decoding output type, default=text]\n\
  -widthcheck [(optional) when -reltol is 0~1, default=false]\n\
  -v/version\n\n";

int main(int argc, const char * argv[]) {
    char inputfile_path[1024];
    char outputfile_enc_path[1024];
    char outputfile_dec_path[1024];
	bool user_output_flag=false;
    char logfile_path[1024];
    bool DEBUG_flag=false;
    int lemblklen=16;
    double alpha_threshold=0.05;
    int max_hit_count=255; 
        // maximum hit count before encoder send out index 
        // adjusting to smaller value can reduce the delay
    int max_input_read=1024;
    int precision=10; // floating point precision for writing into files
	bool LOG_flag=false;
	bool encoding=false;
	bool decoding=false;
	bool decodingonly=false;
    bool delta=false; // delta and residual should be mutually exclusive
    bool residual=false;
    bool range=false;
    double rangemin=0;
    double rangemax=0;
    bool widthcheck=false; // only effective when reltol is on
    double reltol=-1; // relative tolerance (0~1) for min/max filter out operations
	bool multivars = false;
	int varcolumn=-1;
	int history_buffer=1;	// single stream, just one historical buffer
	char typeio[32];
	LEM_IO_TYPE_T eitype=LEM_IO_TEXT;
	LEM_IO_TYPE_T eotype=LEM_IO_BINARY;
	LEM_IO_TYPE_T ditype=LEM_IO_BINARY;
	LEM_IO_TYPE_T dotype=LEM_IO_TEXT;

    for (int i=1 ; i < argc; i++) {
        if (argv[i][0] != '-') {
            printf("%s : error, unknown argument %s\n%s",
                        argv[0],argv[i],usage);
            exit(1);
        }
        else {
            switch (argv[i][1]) {
                case 'h' :
                    if (!strcmp(argv[i], "-help") ||
						!strcmp(argv[i], "-h")) {
                        /* fprintf(stderr,"%s [options]\n",argv[0]); */
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    else if (!strcmp(argv[i], "-history")){
                        history_buffer=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'v':
                    fprintf(stderr,"\n%s\n", VERSION);
                    fprintf(stderr,"%s\n", COPYRIGHT);
                    fprintf(stderr,"Built on %s %s\n\n", __DATE__, __TIME__);
                    exit(0);
                    break;
                case 'd':
                    if (!strcmp(argv[i], "-debug")) {
                        DEBUG_flag=true;
                    }
                    else if (!strcmp(argv[i], "-decode")) {
                        decoding=true;
                    }
                    else if (!strcmp(argv[i], "-decodeonly")) {
                        decoding=true;
                        decodingonly=true;
                        encoding=false;
                    }
                    else if (!strcmp(argv[i], "-delta")) {
                        delta=true;
                        residual=false;
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'e':
                    if (!strcmp(argv[i], "-encode")) {
                        encoding=true;
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'a' :
                    if (!strcmp(argv[i], "-alpha")) {
                        alpha_threshold=atof(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'b' :
                    if (!strcmp(argv[i], "-blocklen")){
                        lemblklen=atoi(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-buffer")){
                        history_buffer=atoi(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-bin")){
                    	eitype=LEM_IO_BINARY;
						eotype=LEM_IO_BINARY;
						ditype=LEM_IO_BINARY;
						dotype=LEM_IO_BINARY;    
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
			
				case 'c' :
					if (!strcmp(argv[i], "-column")){
						varcolumn=atoi(argv[++i]);
						multivars = true;
					}
					else {
						fprintf(stderr,"%s [options]\n",argv[i]);
						fprintf(stderr,"%s",usage);
						exit(1);
					}
					break;
                case 'i' :
                    if (!strcmp(argv[i], "-in") ||
						!strcmp(argv[i], "-i")) {
                        strcpy(inputfile_path, argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'l':
                    if (!strcmp(argv[i], "-log") ||
						!strcmp(argv[i], "-l")) {
                        LOG_flag=true;
                        i++;
                        if ((i < argc) && (argv[i][0] != '-')) {
                        	strcpy(logfile_path, argv[i]);
                        }
                        else {
                            i--;
                        	strcpy(logfile_path, "./idealem_log.txt");
                        }
                    }
                    else if (!strcmp(argv[i], "-lemblklen")) {
                        lemblklen=atoi(argv[++i]);
                    }
					else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'm' :
                    if (!strcmp(argv[i], "-maxhitcount") || 
						!strcmp(argv[i], "-maxhit") ||
						!strcmp(argv[i], "-maxcount")) {
                        max_hit_count=atoi(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-maxread") || 
						!strcmp(argv[i], "-read")) {
                        max_input_read=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'n' :
                    if (!strcmp(argv[i], "-n")) {
                        lemblklen=atoi(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'o':
                    if (!strcmp(argv[i], "-out") ||
						!strcmp(argv[i], "-o")) {
                        i++;
                        if ((i < argc) && (argv[i][0] != '-')) {
                        	strcpy(outputfile_enc_path, argv[i]);
							user_output_flag = true;
							strcpy(outputfile_dec_path, outputfile_enc_path);
                            strcat(outputfile_dec_path, ".o.data");
                        }
                        else {
                            i--;
                        	strcpy(outputfile_enc_path, inputfile_path);
                        	strcat(outputfile_enc_path, ".o.data");
							strcpy(outputfile_dec_path, outputfile_enc_path);
                            strcat(outputfile_dec_path, ".o.data");
                        }
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'p' :
                    if (!strcmp(argv[i], "-precision") ||
						!strcmp(argv[i], "-p")) {
                        precision=atof(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'r':
                    if (!strcmp(argv[i], "-residual")) {
                        residual=true;
                        delta=false;
                    }
                    else if (!strcmp(argv[i], "-range")) {
                        if (delta || residual)
                            range=true;
                        
                        rangemin=atof(argv[++i]);
                        rangemax=atof(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-reltol")) {
                        reltol=atof(argv[++i]);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
				case 't' :
                    if (!strcmp(argv[i], "-threshold")) {
                        alpha_threshold=atof(argv[++i]);
                    }
                    else if (!strcmp(argv[i], "-typeei")) {
                        strcpy(typeio, argv[++i]);
						if (strcmp(typeio, "text") == 0)
							eitype=LEM_IO_TEXT;
						else if (strcmp(typeio, "bin") == 0)
							eitype=LEM_IO_BINARY;
						else {
                        	fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
						}
                    }
					else if (!strcmp(argv[i], "-typeeo")) {
                        strcpy(typeio, argv[++i]);
                        if (strcmp(typeio, "text") == 0)
                            eotype=LEM_IO_TEXT;
                        else if (strcmp(typeio, "bin") == 0)
                            eotype=LEM_IO_BINARY;
                        else {
                            fprintf(stderr,"%s [options]\n",argv[i]);
                            fprintf(stderr,"%s",usage);
                            exit(1);
                        }
                    }
					else if (!strcmp(argv[i], "-typedi")) {
                        strcpy(typeio, argv[++i]);
                        if (strcmp(typeio, "text") == 0)
                            ditype=LEM_IO_TEXT;
                        else if (strcmp(typeio, "bin") == 0)
                            ditype=LEM_IO_BINARY;
                        else {
                            fprintf(stderr,"%s [options]\n",argv[i]);
                            fprintf(stderr,"%s",usage);
                            exit(1);
                        }
                    }
					else if (!strcmp(argv[i], "-typedo")) {
                        strcpy(typeio, argv[++i]);
                        if (strcmp(typeio, "text") == 0)
                            dotype=LEM_IO_TEXT;
                        else if (strcmp(typeio, "bin") == 0)
                            dotype=LEM_IO_BINARY;
                        else {
                            fprintf(stderr,"%s [options]\n",argv[i]);
                            fprintf(stderr,"%s",usage);
                            exit(1);
                        }
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                case 'w':
                    if (!strcmp(argv[i], "-widthcheck")) {
                        if (reltol > 0)
                            widthcheck=true;
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
                default :
                    fprintf(stderr,"%s [options]\n",argv[i]);
                    fprintf(stderr,"%s",usage);
                    exit(1);
                    break;
            }
        }
    }

#ifdef _ENABLE_CXX_IDEALEM

	if (decodingonly)  {
		encoding = false;
		decoding = true;
		if (user_output_flag) {
			strcpy(outputfile_dec_path, outputfile_enc_path);
			strcpy(outputfile_enc_path, inputfile_path);
		}
	}
	else {
		if (decoding && !encoding) {
			decodingonly=true;
			if (user_output_flag) {
				strcpy(outputfile_dec_path, outputfile_enc_path);
				strcpy(outputfile_enc_path, inputfile_path);
			}
		}
	}
	if (encoding) {
		IDEALEM_SINGLE_STREAM idealem_rim_encoding(lemblklen, alpha_threshold);
	    idealem_rim_encoding.init_for_files(inputfile_path, outputfile_enc_path, eitype, eotype, max_hit_count, max_input_read, precision, varcolumn, history_buffer);
	    if (multivars) {
			idealem_rim_encoding.encoding_multivars();
		}
		else {
			if (history_buffer > 1) {
				idealem_rim_encoding.encoding_with_history();
			}
			else {
				idealem_rim_encoding.encoding();
			}
		}
	}

	if (decoding)  {
		if (strlen(outputfile_enc_path) == 0) {
			strcpy(outputfile_enc_path, inputfile_path);
	        strcat(outputfile_enc_path, ".o.data");
	        strcpy(outputfile_dec_path, outputfile_enc_path);
	        strcat(outputfile_dec_path, ".o.data");
		}
		IDEALEM_SINGLE_STREAM idealem_rim_decoding(lemblklen, alpha_threshold, false);
	    idealem_rim_decoding.init_for_files(outputfile_enc_path, outputfile_dec_path, ditype, dotype, max_hit_count, max_input_read, precision, varcolumn, history_buffer);
	    if (multivars) {
			idealem_rim_decoding.decoding_multivars();
		}
		else {
			if (history_buffer > 1) {
				idealem_rim_decoding.decoding_with_history();
			}
			else {
				idealem_rim_decoding.decoding();
			}
		}
	}

#else
	if (decodingonly)  {
		encoding = false;
		decoding = true;
		if (user_output_flag) {
			strcpy(outputfile_dec_path, outputfile_enc_path);
			strcpy(outputfile_enc_path, inputfile_path);
		}
	}
	else {
		if (decoding && !encoding) {
			decodingonly=true;
			if (user_output_flag) {
				strcpy(outputfile_dec_path, outputfile_enc_path);
				strcpy(outputfile_enc_path, inputfile_path);
			}
		}
	}
	// defaults: enc_input=LEM_IO_TEXT, enc_output=LEM_IO_BINARY
	// defaults: dec_input=LEM_IO_BINARY, dec_output=LEM_IO_TEXT
	if (encoding) {
		if (multivars) {
			idealem_file_stream_inout_multivars(inputfile_path, outputfile_enc_path, logfile_path, LOG_flag, DEBUG_flag, lemblklen, alpha_threshold, max_hit_count, max_input_read, varcolumn, eitype, eotype);
		}
		else {
			if (history_buffer > 1) {
				idealem_file_stream_inout_with_history(inputfile_path, outputfile_enc_path, logfile_path, LOG_flag, DEBUG_flag, lemblklen, alpha_threshold, max_hit_count, max_input_read, precision, history_buffer, eitype, eotype, delta, residual, range, rangemin, rangemax, widthcheck, reltol);
			}
			else {
				idealem_file_stream_inout(inputfile_path, outputfile_enc_path, logfile_path, LOG_flag, DEBUG_flag, lemblklen, alpha_threshold, max_hit_count, max_input_read, precision, eitype, eotype, delta, residual, range, rangemin, rangemax, widthcheck, reltol);
			}
		}
	}

	if (decoding) {
		if (strlen(outputfile_enc_path) == 0) {
			strcpy(outputfile_enc_path, inputfile_path);
	        strcat(outputfile_enc_path, ".o.data");
	        strcpy(outputfile_dec_path, outputfile_enc_path);
	        strcat(outputfile_dec_path, ".o.data");
		}
		if (multivars) {
			idealem_file_stream_decoding_multivars(outputfile_enc_path, outputfile_dec_path, logfile_path, LOG_flag, DEBUG_flag, lemblklen, alpha_threshold, max_hit_count, max_input_read, varcolumn, ditype, dotype);
		}
		else {
			if (history_buffer > 1) {
				idealem_file_stream_decoding_with_history(outputfile_enc_path, outputfile_dec_path, logfile_path, LOG_flag, DEBUG_flag, lemblklen, alpha_threshold, max_hit_count, max_input_read, precision, history_buffer, ditype, dotype, delta, residual, range, rangemin, rangemax);
			}
			else {
				idealem_file_stream_decoding(outputfile_enc_path, outputfile_dec_path, logfile_path, LOG_flag, DEBUG_flag, lemblklen, alpha_threshold, max_hit_count, max_input_read, precision, ditype, dotype, delta, residual, range, rangemin, rangemax);
			}
		}
	}

#endif // _ENABLE_CXX_IDEALEM
	
    return 0;
}

