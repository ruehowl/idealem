/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * Last updated on Mon Feb 29 15:45:12 PST 2016
 * created on Thu Jan 21 07:33:22 PST 2016
 *
 */
//
// kstest.c
// Kolmogorov-Smirnov test
//
// KS Test References: 
// https://en.wikipedia.org/wiki/Kolmogorov-Smirnov_test
// G. Marsaglia, W. Tsang, J. Wang, "Evaluating Kolmogorov's distribution", 
//   Journal of Statistical Software, 2003. http://www.jstatsoft.org/v08/i18/
//
#include <stdio.h>
#include <math.h>
//#include <idealem_const.h>

#ifdef _ENABLE_CXX_IDEALEM
extern "C" {
#endif

#define KS_MMAX(x, y) (((x)>(y))?(x):(y))

#ifdef _ENABLE_CXX_IDEALEM
inline int nearestint(double x) {
#else
int nearestint(double x) {
#endif

// Round to nearest integer. 
// Rounds half integers to the nearest even integer
  int i;
  
  if (x >= 0) {
    i = (int)(x + 0.5);
    if ( (i & 1) && (x + 0.5) == i ) i--;
  }
  else {
    i = (int)(x - 0.5);
    if ( (i & 1) && (x - 0.5) == i ) i++;
  }
  
  return i;
}

double KSprob(double z) {
// Calculates the Kolmogorov distribution function,
// which gives the probability that Kolmogorov's test statistic will exceed
// the value z assuming the null hypothesis.
//
// NOTE: To compare two experimental distributions with m and n events,
//       use z = sqrt(m*n/(m+n))*dn
//
  
  double fj[4] = {-2,-8,-18,-32};
  double r[4];
  const double w = 2.50662827;
  
// const1 - -pi**2/8, const2 = 9*const1, const3 = 25*const1
  const double const1 = -1.2337005501361697;
  const double const2 = -11.103304951225528;
  const double const3 = -30.842513753404244;
  
  double u = fabs(z);
  double p;
  if (u < 0.2) {
    p = 1;
  }
  else if (u < 0.755) {
    double v = 1.0/(u*u);
    p = 1 - w*(exp(const1*v) + exp(const2*v) + exp(const3*v))/u;
  }
  else if (u < 6.8116) {
    r[1] = 0;
    r[2] = 0;
    r[3] = 0;
    double v = u*u;
    int maxj = KS_MMAX(1,nearestint(3.0/u));
    for (int j=0; j < maxj; j++) {
      r[j] = exp(fj[j]*v);
    }
    p = 2*(r[0] - r[1] + r[2] - r[3]);
  }
  else {
    p = 0;
  }
  
  return p;
}


double KStest(const double* a, int n_a, const double* b, int n_b) {
// KS test whether two one-dimensional data sets are similar
// statistically from the same parent distribution,
// Comparinh two experimental distributions of unbinned data.
// The test statistic is the maximum deviation between the two 
// integrated distribution functions, multiplied by 
// the normalizing factor (rdmax*sqrt(n_a*n_b/(n_a+n_b))).
//
// Input:
// a,b: One-dimensional arrays of length n_a, n_b, respectively.
//      The elements of a and b must be given in ascending order.
//
// Output:
// The returned value is a probability indicating compatibility of a and b.
// Values close to zero are taken as indicating a small probability
// of compatibility. For two data sets drawn randomly from the same parent
// distribution, the value should be uniformly distributed between
// zero and one.
// In case of error the function return -1.
// If the 2 sets have a different number of points, the minimum of
// the two sets is used.
//
  
  double prob = -1;
  
  if (!a || !b) {
    printf("KolmogorovTest : NULL pointer");
    return prob;
  }
  // Require at least two points in each graph
  if (!a || !b || n_a <= 2 || n_b <= 2) {
    //printf("KolmogorovTest : Sets must have more than 2 points");
    return 0;
  }
  //     Constants needed
  double rna = n_a;
  double rnb = n_b;
  double sa  = 1./rna;
  double sb  = 1./rnb;
  double rdiff = 0;
  double rdmax = 0;
  int ia = 0;
  int ib = 0;
  
  // Main loop over point sets to find max distance
  // rdiff is the running difference, and rdmax the max.
  int done = 0;
  
  for (int i=0; i < (n_a+n_b);i++) {
    if (a[ia] < b[ib]) {
      rdiff -= sa;
      ia++;
      if (ia >= n_a) {done = 1; break;}
    }
    else if (a[ia] > b[ib]) {
      rdiff += sb;
      ib++;
      if (ib >= n_b) {done = 1; break;}
    }
    else {
      // special cases for the ties
      double x = a[ia];
      while(a[ia] == x && ia < n_a) {
        rdiff -= sa;
        ia++;
      }
      while(b[ib] == x && ib < n_b) {
        rdiff += sb;
        ib++;
      }
      if (ia >= n_a) {done = 1; break;}
      if (ib >= n_b) {done = 1; break;}
    }
    
    rdmax = fmax(rdmax,fabs(rdiff));
  }
  
  if (done) {
    rdmax = fmax(rdmax,fabs(rdiff));
    double z = rdmax * sqrt(rna*rnb/(rna+rnb));
    prob = KSprob(z);
  }
  // debug printout
  //printf(" Kolmogorov Probability = %g, Max Dist = %g\n",prob,rdmax);
  
  return prob;
}

#ifdef _ENABLE_CXX_IDEALEM
}
#endif

