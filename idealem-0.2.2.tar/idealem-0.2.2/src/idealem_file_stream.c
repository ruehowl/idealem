/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * last updated on Mon Feb 29 15:42:06 PST 2016
 *
 */
//
// idealem_file_stream.c
// files as input and output
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//#include <idealem_const.h>
#include <idealem_common.h>
#include <idealem_util.h>
#include <idealem_file_stream.h>

#ifndef _ENABLE_CXX_IDEALEM

size_t read_double(void *ptr, size_t nitems, FILE *stream, int max_input_read) {
    size_t i;
    char line[max_input_read];
    for (i=0; i<nitems; i++) {
        if (!fgets(line, sizeof(line), stream)) break;
        *((double *)ptr + i) = atof(line);
    }
    return i;
}

size_t read_double_bin(void *ptr, size_t nitems, FILE *stream) {
	size_t count = fread((double *)ptr, sizeof(double), nitems, stream);
    return count;
}

// mptr : buffer for the line
// column : which variable/column (number) to collect based on 0
// ptr : buffer for the variable/column
int read_double_in_multivars(void* mptr, int column, void *ptr, size_t nitems, FILE *stream, int max_input_read) {
    int i, jcol;
    char line[max_input_read];
    for (i=0; i<nitems; i++) {
        if (!fgets(line, sizeof(line), stream)) break;
		((char**)mptr)[i] = strdup(line);	
		jcol=0;
		char* tk=NULL;
		for (char *ti=strtok_r(line, " ,", &tk); ti != NULL; ti=strtok_r(tk, " ,", &tk)) {
			if (jcol == column) {
				//printf("%d GOOD ti=%s value=%.10lf : line=%s\n", i, ti, atof(ti), line);
				*((double *)ptr + i) = atof(ti);
			}
			jcol++;
			/*
			char value[max_input_read];
			strcpy(value,"");
			char* tj=strchr(ti,' ');
			if (tj == NULL) strcpy(value, ti);
			else {
				for (; tj!=NULL; tj=strchr(value, ' ')) strcat(value, tj+1);
			}
			*/
		}
    }
    return i;
}

// FIX: Have NOT been updated yet for binary
int read_double_in_multivars_bin(void* mptr, int column, void *ptr, size_t nitems, FILE *stream, int max_input_read) {
    int i, jcol;
    char line[max_input_read];
    for (i=0; i<nitems; i++) {
        if (!fgets(line, sizeof(line), stream)) break;
		((char**)mptr)[i] = strdup(line);	
		jcol=0;
		char* tk=NULL;
		for (char *ti=strtok_r(line, " ,", &tk); ti != NULL; ti=strtok_r(tk, " ,", &tk)) {
			if (jcol == column) {
				//printf("%d GOOD ti=%s value=%.10lf : line=%s\n", i, ti, atof(ti), line);
				*((double *)ptr + i) = atof(ti);
			}
			jcol++;
			/*
			char value[max_input_read];
			strcpy(value,"");
			char* tj=strchr(ti,' ');
			if (tj == NULL) strcpy(value, ti);
			else {
				for (; tj!=NULL; tj=strchr(value, ' ')) strcat(value, tj+1);
			}
			*/
		}
    }
    return i;
}

int read_hit_count(void *ptr, size_t nitems, FILE *stream, int max_input_read) {
    int i;
    char line[max_input_read];
    for (i=0; i<nitems; i++) {
        if (!fgets(line, sizeof(line), stream)) break;
        *((unsigned char *)ptr + i) = (unsigned char)atoi(line);
    }
    return i;
}

size_t read_hit_count_bin(void *ptr, size_t nitems, FILE *stream) {
	size_t count = fread((unsigned char *)ptr, sizeof(unsigned char), 1, stream);
    return count;
}

int write_double(const void *ptr, size_t nitems, FILE *stream, int precision) {
    int i;
    for (i=0; i<nitems; i++) {
        if (!fprintf(stream, "%.*f\n", precision, *((double *)ptr + i)))
            break;
    }
    return i;
}

size_t write_double_bin(const void *ptr, size_t nitems, FILE *stream) {
	size_t count = fwrite((double *)ptr, sizeof(double), nitems, stream);
    return count;
}

int write_multivars(const void *mptr, size_t nitems, FILE *stream) {
    int i;
    for (i=0; i<nitems; i++) {
		//printf("%d line=%s", i, ((char**)mptr)[i]);
        if (!fprintf(stream, "%s", ((char**)mptr)[i]))	// writing the line buffers
            break;
    }
    return i;
}

// FIX: Have NOT been updated yet for binary
int write_multivars_bin(const void *mptr, size_t nitems, FILE *stream) {
    int i;
    for (i=0; i<nitems; i++) {
		//printf("%d line=%s", i, ((char**)mptr)[i]);
        if (!fprintf(stream, "%s", ((char**)mptr)[i]))	// writing the line buffers
            break;
    }
    return i;
}

int write_a_string(const void *mptr, FILE *stream) {
    fprintf(stream, "%s", (char*)mptr);	// writing the string line buffer
    return 1;
}

int write_hit_count(const void *ptr, size_t nitems, FILE *stream) {
    int i;
    for (i=0; i<nitems; i++) {
        if (!fprintf(stream, "%u\n", *((unsigned char *)ptr + i)))
            break;
    }
    return i;
}

int write_hit_count_bin(const void *ptr, size_t nitems, FILE *stream) {
	int count = fwrite((unsigned char *)ptr, sizeof(unsigned char), 1, stream);
    return count;
}

int write_cdf(const LEM_BLOCK* partitions, int nitems, FILE *stream, int partitionscnt, int partitionsnum) {
    int i;
    unsigned char partitionsidx;  // partitions index to be written on output file
  
    if (partitionscnt >= partitionsnum) { // when partitions are fully populated
		for (i=0; i < partitionsnum; i++) {
			partitionsidx = partitionscnt % partitionsnum;
			fwrite(partitions[partitionsidx].block, sizeof(double), nitems, stream);
			partitionscnt++;
		}
    }
    else { // when partitions are not populated till the end (should rarely happen)
		for (i=0; i < partitionscnt; i++) {
			fwrite(partitions[i].block, sizeof(double), nitems, stream);
		}
    }
    return partitionscnt;
}

/* Print floating values stored in buffer using the permuted sequence */
void permuted_output(int cnt, double* buffer, int lemblklen, FILE* outputfile_d, int precision) {
    int i;
	int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
    while (cnt--) {
        randperm(lemblklen, permsequence); // random shuffle
        for (i=0; i < lemblklen; i++) {
            //printf("%f\n", buffer->blk[perm[i]]); 
				// print floating values using the permuted sequence
            write_double((buffer + permsequence[i]), 1, outputfile_d, precision); 
				// file output shuffled for values stored in buffer
        }
    }

    return;
}

void permuted_output_bin(int cnt, double* buffer, int lemblklen, FILE* outputfile_d) {
    int i;
	int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
    while (cnt--) {
        randperm(lemblklen, permsequence); // random shuffle
        for (i=0; i < lemblklen; i++) {
            //printf("%f\n", buffer->blk[perm[i]]); 
				// print floating values using the permuted sequence
            write_double_bin((buffer + permsequence[i]), 1, outputfile_d);
				// file output shuffled for values stored in buffer
        }
    }

    return;
}

/* Print floating values stored in line buffer using the permuted sequence */
void permuted_output_in_multivars(int cnt, char** buffer, int lemblklen, FILE* outputfile_d) {
    int i;
	int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
    while (cnt--) {
        randperm(lemblklen, permsequence); // random shuffle
        for (i=0; i < lemblklen; i++) {
			//printf("%d line=%s", i, buffer[permsequence[i]]);
			write_a_string(buffer[permsequence[i]], outputfile_d); 
				// file output shuffled for values stored in buffer
        }
    }

    return;
}

// FIX later for binary output
void permuted_output_in_multivars_bin(int cnt, char** buffer, int lemblklen, FILE* outputfile_d) {
    int i;
	int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
    while (cnt--) {
        randperm(lemblklen, permsequence); // random shuffle
        for (i=0; i < lemblklen; i++) {
			//printf("%d line=%s", i, buffer[permsequence[i]]);
			write_a_string(buffer[permsequence[i]], outputfile_d); 
				// file output shuffled for values stored in buffer
        }
    }

    return;
}

void permuted_output_cdf(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d, int precision) {
	int i;
	int* permsequence; // permutation sequence for decoding samples
	permsequence = (int*)alloca(sizeof(int)*lemblklen);
  
	if (partitions[partitionsidx].count) { // if this is the repeated use case of lemblk
		randperm(lemblklen, permsequence); // random shuffle
    
		for (i=0; i < lemblklen; i++) {
			//printf("%f\n", partitions[partitionsidx].block[permsequence[i]]); 
			// print floating values stored in partition
			// binary output
			// fwrite((partitions[partitionsidx].block + permsequence[i]), sizeof(double), 1, outputfile_d); 
			// FILE OUTPUT (values stored in partition)
			// text output
			write_double((partitions[partitionsidx].block + permsequence[i]), 1, outputfile_d, precision); 
		}
	}
	else { // the first use case
		// for (i=0; i < lemblklen; i++) 
			// printf("%f\n", partitions[partitionsidx].block[i]); 
			// print floating values stored in partition
		// binary output
		// fwrite(partitions[partitionsidx].block, sizeof(double), lemblklen, outputfile_d); 
			// FILE OUTPUT AS IS (values stored in partition)
		// text output
		write_double(partitions[partitionsidx].block, lemblklen, outputfile_d, precision); 
		
		partitions[partitionsidx].count++;
	}
    
    return;
}

void permuted_output_cdf_bin(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d) {
	int i;
	int* permsequence; // permutation sequence for decoding samples
	permsequence = (int*)alloca(sizeof(int)*lemblklen);
  
	if (partitions[partitionsidx].count) { // if this is the repeated use case of lemblk
		randperm(lemblklen, permsequence); // random shuffle
    
		for (i=0; i < lemblklen; i++) {
			//printf("%f\n", partitions[partitionsidx].block[permsequence[i]]); 
			// print floating values stored in partition
			// FILE OUTPUT (values stored in partition)
			// text output
			write_double_bin((partitions[partitionsidx].block + permsequence[i]), 1, outputfile_d);
		}
	}
	else { // the first use case
		// for (i=0; i < lemblklen; i++) 
			// printf("%f\n", partitions[partitionsidx].block[i]); 
			// print floating values stored in partition
			// FILE OUTPUT AS IS (values stored in partition)
		write_double_bin(partitions[partitionsidx].block, lemblklen, outputfile_d);
		
		partitions[partitionsidx].count++;
	}
    
    return;
}

void deltaresidual_output_cdf(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d, int precision, double* valrecover, bool delta, bool range, double rangemin, double rangemax) {
    int i;
    
    valrecover[0] = partitions[partitionsidx].block[0]; // base value
    if (delta) {
        for (i=1; i < lemblklen; i++)
            valrecover[i] = valrecover[i-1] + partitions[partitionsidx].block[i]; // delta recovery
    }
    else { // automatically residual
        for (i=1; i < lemblklen; i++)
            valrecover[i] = partitions[partitionsidx].block[0] + partitions[partitionsidx].block[i]; // residual recovery
    }
    
    if (range) { // ensure values are withing the range
        for (i=0; i < lemblklen; i++) {
            if (valrecover[i] < rangemin)
                valrecover[i] += (rangemax - rangemin);
            else if (valrecover[i] >= rangemax)
                valrecover[i] -= (rangemax - rangemin);
        }
    }
    
    write_double(valrecover, lemblklen, outputfile_d, precision);
        
    return;
}

void deltaresidual_output_cdf_bin(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d, double* valrecover, bool delta, bool range, double rangemin, double rangemax) {
    int i;
    
    valrecover[0] = partitions[partitionsidx].block[0]; // base value
    if (delta) {
        for (i=1; i < lemblklen; i++)
            valrecover[i] = valrecover[i-1] + partitions[partitionsidx].block[i]; // delta recovery
    }
    else { // automatically residual
        for (i=1; i < lemblklen; i++)
            valrecover[i] = partitions[partitionsidx].block[0] + partitions[partitionsidx].block[i]; // residual recovery
    }
    
    if (range) { // ensure values are within the range
        for (i=0; i < lemblklen; i++) {
            if (valrecover[i] < rangemin)
                valrecover[i] += (rangemax - rangemin);
            else if (valrecover[i] >= rangemax)
                valrecover[i] -= (rangemax - rangemin);
        }
    }
    
    write_double_bin(valrecover, lemblklen, outputfile_d);
    
    return;
}

int idealem_file_stream_inout(const char* inputfile_path, const char* outputfile_enc_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax, bool widthcheck, double reltol) {

    FILE* inputfile_d;
    FILE* outputfile_enc_d;
    char outputfile_dec_path[1024];
    FILE* logfile_d = NULL;
    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen
    //long timestep = 0;
    bool exchangeability = false;
    int i=0; // index for loop
    double* basevals; // base values store
    basevals = (double*)alloca(sizeof(double)*max_hit_count);
    
    bool buffered = false;  // if buffer is occupied
    unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits 
		// with previous buffer to be written to the output
    
    double* block_samples;  // sample block array
    double* sorted_block;  // sorted sample block array for KS test
    double* prev_sorted_block;  // previous sorted sample block for KS test
    AUX_BLOCK* prev_aux; // for relative tolerance (reltol)

    block_samples = (double*)alloca(sizeof(double)*lemblklen);
    sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    prev_sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    prev_aux = (AUX_BLOCK*)alloca(sizeof(AUX_BLOCK));

	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	if (i_type == LEM_IO_TEXT)	// default
	    inputfile_d = fopen(inputfile_path, "r" );
	else // i_type == LEM_IO_BINARY
	    inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
    
	if ((outputfile_enc_path == NULL) || (strlen(outputfile_enc_path) == 0)) {
		strcpy((char*)outputfile_enc_path, inputfile_path);
		strcat((char*)outputfile_enc_path, ".o.data");
		strcpy((char*)outputfile_dec_path, outputfile_enc_path);
		strcat((char*)outputfile_dec_path, ".o.data");
	}
	if (o_type == LEM_IO_TEXT)
	    outputfile_enc_d = fopen(outputfile_enc_path, "w" );
	else 	// o_type == LEM_IO_BINARY  // default
    	outputfile_enc_d = fopen(outputfile_enc_path, "wb" );
	if (!outputfile_enc_d) {
		printf("couldn't open output file for encoded data %s\n", outputfile_enc_path);
		exit(1);
	}
    
	if (LOG_flag) {
		if (logfile_path == NULL) {
	        strcpy((char*)logfile_path, "./idealem_log.txt");
		}
	    logfile_d = fopen(logfile_path, "a");
	    if (logfile_d) {
	        log_to_file(logfile_d, "IDEADLEM_START");
		} else {
			printf("couldn't open log file %s\n", logfile_path);
			exit(1);
		}
	}
  
// ENCODING
// statistical data reduction for a single stream input from a text file
// 
	if (i_type == LEM_IO_TEXT)	// default
		block_size = (int)read_double(block_samples, lemblklen, inputfile_d, max_input_read);
	else
		block_size = (int)read_double_bin(block_samples, lemblklen, inputfile_d);
//    while ((block_size = (int)read_double(block_samples, lemblklen, inputfile_d, max_input_read)) ) {
	while (block_size) {
        
        //timestep += block_size;
        //printf("timestep: %ld\n", timestep);
        if (delta) { // compute delta in reverse order
            for (i=block_size-1; i > 0; i--)
                block_samples[i] -= block_samples[i-1];
        }
        else if (residual) { // first subtract base value from every other value
            for (i=1; i < block_size; i++)
                block_samples[i] -= block_samples[0];
        }
        
        if (range) { // standardization
            double diffmax = (rangemax-rangemin)/2.0; // -diffmax < diffvalue <= diffmax
            
            for(i=1; i < block_size; i++) {
                if (block_samples[i] <= -diffmax)
                    block_samples[i] += (rangemax - rangemin);
                else if (block_samples[i] > diffmax)
                    block_samples[i] -= (rangemax - rangemin);
            }
        }
        
        memcpy(sorted_block, block_samples, sizeof(double)*block_size);
        // sort for a valid input to KStest()
        if (delta || residual)
            qsort(sorted_block+1, block_size-1, sizeof(double), compare);
        else
            qsort(sorted_block, block_size, sizeof(double), compare);
			// sort for a valid input to KStest()
        
        if (buffered) { // when buffer is non-empty for all cases except initial one
            if (delta || residual) { // exchangeability test w/o base value
                if (reltol > 0) {
                    if (widthcheck) {
                        if ( (prev_aux->minmintol > sorted_block[1]) || (prev_aux->maxmaxtol < sorted_block[block_size-1]) || ( ((1-reltol)*prev_aux->width) > (sorted_block[block_size-1]-sorted_block[1]) ) || ( ((1+reltol)*prev_aux->width) < (sorted_block[block_size-1]-sorted_block[1]) ) )
                            continue; // continue the loop w/o KS-test if the value OR the ratio falls outside of tolerance range
                    }
                    else {
                        if ( (prev_aux->minmintol > sorted_block[1]) || (prev_aux->minmaxtol < sorted_block[1]) || (prev_aux->maxmaxtol < sorted_block[block_size-1]) || (prev_aux->maxmintol > sorted_block[block_size-1]) )
                            continue; // continue the loop w/o KS-test if the value falls outside of tolerance range
                    }
                }
                exchangeability = idealem_exchangeability_single_stream(sorted_block+1, block_size-1, prev_sorted_block+1, block_size-1, alpha_threshold, &hitcntbyte);
            }
            else { // exchnageability test in normal mode
                if (reltol > 0) { // min/max filter out operations
                    if (widthcheck) {
                        if ( (prev_aux->minmintol > sorted_block[0]) || (prev_aux->maxmaxtol < sorted_block[block_size-1]) || ( ((1-reltol)*prev_aux->width) > (sorted_block[block_size-1]-sorted_block[0]) ) || ( ((1+reltol)*prev_aux->width) < (sorted_block[block_size-1]-sorted_block[0]) ) )
                            continue;
                    }
                    else {
                        if ( (prev_aux->minmintol > sorted_block[0]) || (prev_aux->minmaxtol < sorted_block[0]) || (prev_aux->maxmaxtol < sorted_block[block_size-1]) || (prev_aux->maxmintol > sorted_block[block_size-1]) )
                            continue;
                    }
                }
                exchangeability = idealem_exchangeability_single_stream(sorted_block, block_size, prev_sorted_block, block_size, alpha_threshold, &hitcntbyte);
            }
            
			if (exchangeability) {  // exchangeable
                basevals[hitcntbyte] = block_samples[0];
                
                if (hitcntbyte == max_hit_count) { // if hit count reaches max_hit_count
                    if (o_type == LEM_IO_TEXT)
						write_hit_count(&hitcntbyte, 1, outputfile_enc_d); // hit count
					else	// default
						write_hit_count_bin(&hitcntbyte, 1, outputfile_enc_d);
                    
                    if (delta || residual) { // base value output
                        if (o_type == LEM_IO_TEXT)
                            write_double(basevals, max_hit_count, outputfile_enc_d, precision);
                        else
                            write_double_bin(basevals, max_hit_count, outputfile_enc_d);
                    }
                    
					hitcntbyte=0;
                }
       			//printf("exc max_hit_count: %d\n", hitcntbyte);
			}
            else { // non-exchangeable
				if (o_type == LEM_IO_TEXT)
                	write_hit_count(&hitcntbyte, 1, outputfile_enc_d); // hit count
				else	// default
					write_hit_count_bin(&hitcntbyte, 1, outputfile_enc_d);
                
                if (delta || residual) { // base value output + updating prev_aux
                    if (o_type == LEM_IO_TEXT)
                        write_double(basevals, hitcntbyte, outputfile_enc_d, precision);
                    else
                        write_double_bin(basevals, hitcntbyte, outputfile_enc_d);
                    
                    if (reltol > 0) {
                        prev_aux->minmintol = sorted_block[1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        prev_aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        if (widthcheck) {
                            prev_aux->width = sorted_block[block_size-1] - sorted_block[1];
                        }
                        else {
                            prev_aux->minmaxtol = sorted_block[1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                            prev_aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        }
                    }
                }
                else { // updating prev_aux
                    if (reltol > 0) {
                        prev_aux->minmintol = sorted_block[0] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        prev_aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        if (widthcheck) {
                            prev_aux->width = sorted_block[block_size-1] - sorted_block[0];
                        }
                        else {
                            prev_aux->minmaxtol = sorted_block[0] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                            prev_aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        }
                    }
                }
                
				hitcntbyte=0;
                memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size);
					// copy sorted samples to previous sorted block
				if (o_type == LEM_IO_TEXT)
					write_double(block_samples, lemblklen, outputfile_enc_d, precision); // CDF OUTPUT
				else	// default
					write_double_bin(block_samples, lemblklen, outputfile_enc_d);
       			//printf("non-exc max_hit_count: %d\n", hitcntbyte);
            }
        }
        else { // when buffer is empty, the initial case
            memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size); 
				// copy sorted sample blk  to previous sorted block
            
            // updating
            if (delta || residual) {
                if (reltol > 0) {
                    prev_aux->minmintol = sorted_block[1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                    prev_aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                    if (widthcheck) {
                        prev_aux->width = sorted_block[block_size-1] - sorted_block[1];
                    }
                    else {
                        prev_aux->minmaxtol = sorted_block[1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        prev_aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                    }
                }
            }
            else {
                if (reltol > 0) {
                    prev_aux->minmintol = sorted_block[0] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                    prev_aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                    if (widthcheck) {
                        prev_aux->width = sorted_block[block_size-1] - sorted_block[0];
                    }
                    else {
                        prev_aux->minmaxtol = sorted_block[0] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        prev_aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                    }
                }
            }
            
			if (o_type == LEM_IO_TEXT)
				write_double(block_samples, lemblklen, outputfile_enc_d, precision); // CDF OUTPUT
			else	// default
				write_double_bin(block_samples, lemblklen, outputfile_enc_d);
            buffered=true; // now we have previous buffer
        }
		
		if (i_type == LEM_IO_TEXT)	// default
			block_size = (int)read_double(block_samples, lemblklen, inputfile_d, max_input_read);
		else
			block_size = (int)read_double_bin(block_samples, lemblklen, inputfile_d);
    }
    
    // for the last sample data
	if (o_type == LEM_IO_TEXT)
		write_hit_count(&hitcntbyte, 1, outputfile_enc_d); // hit count
	else	// default
		write_hit_count_bin(&hitcntbyte, 1, outputfile_enc_d);
        
    fclose(inputfile_d);
    fclose(outputfile_enc_d);
    if (LOG_flag) fclose(logfile_d);
    
    return 0;
}

int idealem_file_stream_inout_multivars(const char* inputfile_path, const char* outputfile_enc_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int colno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type) {

    FILE* inputfile_d;
    FILE* outputfile_enc_d;
    //char outputfile_dec_path[1024];
    FILE* logfile_d = NULL;
    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen
    //long timestep = 0;
    bool buffered = false;  // if buffer is occupied
    unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits 
		// with previous buffer to be written to the output
    
    char** line_samples;  // sample block array for lines
    char** lastline_samples;  // sample block array for the last lines
    double* block_samples;  // sample block array
    double* sorted_block;  // sorted sample block array for KS test
    double* prev_sorted_block;  // previous sorted sample block for KS test
	
	int i=0; // index for loop

    line_samples = (char **)malloc(lemblklen * sizeof(char *));
    for (i=0; i<lemblklen; i++)
		line_samples[i] = (char *)malloc(max_input_read * sizeof(char));
    lastline_samples = (char **)malloc(lemblklen * sizeof(char *));
    for (i=0; i<lemblklen; i++)
		lastline_samples[i] = (char *)malloc(max_input_read * sizeof(char));
	block_samples = (double*)alloca(sizeof(double)*lemblklen);
    sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    prev_sorted_block = (double*)alloca(sizeof(double)*lemblklen);

	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	if (i_type == LEM_IO_TEXT) 	// default
		inputfile_d = fopen(inputfile_path, "r" );
	else	// i_type == LEM_IO_BINARY
		inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
    
	if ((outputfile_enc_path == NULL) || (strlen(outputfile_enc_path) == 0)) {
		strcpy((char*)outputfile_enc_path, inputfile_path);
		strcat((char*)outputfile_enc_path, ".o.data");
		//strcpy((char*)outputfile_dec_path, outputfile_enc_path);
		//strcat((char*)outputfile_dec_path, ".o.data");
	}
	if (o_type == LEM_IO_TEXT)
		outputfile_enc_d = fopen(outputfile_enc_path, "w" );
	else	// o_type == LEM_IO_BINARY	// default
		outputfile_enc_d = fopen(outputfile_enc_path, "w" );	// wb
	// FIX wb later, as string binary output is not ready
	if (!outputfile_enc_d) {
		printf("couldn't open output file for encoded data %s\n", outputfile_enc_path);
		exit(1);
	}
    
	if (LOG_flag) {
		if (logfile_path == NULL) {
	        strcpy((char*)logfile_path, "./idealem_log.txt");
		}
	    logfile_d = fopen(logfile_path, "a");
	    if (logfile_d) {
	        log_to_file(logfile_d, "IDEADLEM_START");
		} else {
			printf("couldn't open log file %s\n", logfile_path);
			exit(1);
		}
	}
  
// ENCODING
// statistical data reduction for a single stream input from a text file
// 
	if (i_type == LEM_IO_TEXT) 	// default
		block_size = (int)read_double_in_multivars(line_samples, colno, block_samples, lemblklen, inputfile_d, max_input_read);
	else	// i_type == binary
		block_size = (int)read_double_in_multivars_bin(line_samples, colno, block_samples, lemblklen, inputfile_d, max_input_read);
		
//    while ((block_size = (int)read_double_in_multivars(line_samples, colno, block_samples, lemblklen, inputfile_d, max_input_read)) ) {
    while (block_size) {
        
        //timestep += block_size;
        //printf("timestep: %ld\n", timestep);
        
        memcpy(sorted_block, block_samples, sizeof(double)*block_size);
        qsort(sorted_block, block_size, sizeof(double), compare); 
			// sort for a valid input to KStest()
		
		// check this last line buffer and see if it can be relocated somewhere below
	    for (i=0; i<lemblklen; i++)
			memcpy(lastline_samples[i], line_samples[i], sizeof(char)*max_input_read);
        
        if (buffered) { 
			// when buffer is non-empty for all cases except initial one
			if (idealem_exchangeability_single_stream(sorted_block, block_size, prev_sorted_block, block_size, alpha_threshold, &hitcntbyte)) {  // exchangeable
                if (hitcntbyte == max_hit_count) { // if hit count reaches max_hit_count
                    //write_a_string(line_samples[lemblklen-1], outputfile_enc_d);
					if (o_type == LEM_IO_TEXT)
						write_hit_count(&hitcntbyte, 1, outputfile_enc_d); // hit count
					else	// default
						write_hit_count(&hitcntbyte, 1, outputfile_enc_d);
						// FIX because write_multivars_bin is not ready. When ready, write_hit_count_bin().
					//write_multivars(line_samples, lemblklen, outputfile_enc_d);
					hitcntbyte=0;
                }
       			//printf("exc max_hit_count: %d\n", hitcntbyte);
			}
            else { // non-exchangeable
				if (o_type == LEM_IO_TEXT)
					write_hit_count(&hitcntbyte, 1, outputfile_enc_d); // hit count
				else	// default
					write_hit_count(&hitcntbyte, 1, outputfile_enc_d); 
					// FIX because write_multivars_bin is not ready. When ready, write_hit_count_bin().
				hitcntbyte=0;
                memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size); 
					// copy sorted samples to previous sorted block
				if (o_type == LEM_IO_TEXT)
					write_multivars(line_samples, lemblklen, outputfile_enc_d);
				else	// default
					write_multivars_bin(line_samples, lemblklen, outputfile_enc_d);
       			//printf("non-exc max_hit_count: %d\n", hitcntbyte);
            }
        }
        else { // when buffer is empty, the initial case
            memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size); 
				// copy sorted sample blk  to previous sorted block
			if (o_type == LEM_IO_TEXT)
				write_multivars(line_samples, lemblklen, outputfile_enc_d); // CDF OUTPUT
			else 	// default
				write_multivars_bin(line_samples, lemblklen, outputfile_enc_d);
            buffered=true; // now we have previous buffer
        }
    }
    
    // for the last sample data
	if (o_type == LEM_IO_TEXT)
		write_hit_count(&hitcntbyte, 1, outputfile_enc_d); // hit count
	else	//default
		write_hit_count(&hitcntbyte, 1, outputfile_enc_d); 
		// FIX because write_multivars_bin is not ready. When ready, write_hit_count_bin().
	//printf("last max_hit_count: %d\n", hitcntbyte);
	//write_multivars(lastline_samples, lemblklen, outputfile_enc_d);
	//write_a_string(line_samples[lemblklen-1], outputfile_enc_d);
        
    fclose(inputfile_d);
    fclose(outputfile_enc_d);
    if (LOG_flag) fclose(logfile_d);
    
    return 0;
}

// ENCODING
// with historical buffers
int idealem_file_stream_inout_with_history(const char* inputfile_path, const char* outputfile_enc_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, int bufferno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax, bool widthcheck, double reltol) {

    FILE* inputfile_d;
    FILE* outputfile_enc_d;
    FILE* logfile_d = NULL;
	
	int partitionsnum = bufferno; // number of historical buffers, default=1
	int partitionscnt = 0;  // partition cnt to keep track of
	unsigned char partitionsidx;  // partitions index to be written to output file
	
    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen
    //long timestep = 0;
    
    bool exchangeabilty = false;
    unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits (exchangeability)
		// with previous buffer to be written to the output
    int i=0; // index for loop
	
    double* block_samples;  // sample block array
    double* sorted_block;  // sorted sample block array for KS test
	LEM_BLOCK* partitions;

    block_samples = (double*)alloca(sizeof(double)*lemblklen);
    sorted_block = (double*)alloca(sizeof(double)*lemblklen);
	partitions = (LEM_BLOCK*)alloca(sizeof(LEM_BLOCK)*partitionsnum);
    
    if (reltol > 0) { // relative tolerance (0~1) for min/max filter out operations
        for (i=0; i < partitionsnum; i++) {
            partitions[i].block = (double*)alloca(sizeof(double)*lemblklen);
            partitions[i].sorted_block = (double*)alloca(sizeof(double)*lemblklen);
            partitions[i].aux = (AUX_BLOCK*)alloca(sizeof(AUX_BLOCK));
        }
    }
    else {
        for (i=0; i < partitionsnum; i++) {
            partitions[i].block = (double*)alloca(sizeof(double)*lemblklen);
            partitions[i].sorted_block = (double*)alloca(sizeof(double)*lemblklen);
        }
    }

	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	if (i_type == LEM_IO_TEXT)	// default
		inputfile_d = fopen(inputfile_path, "r" );
	else	// i_type == LEM_IO_BINARY
		inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
    
	if ((outputfile_enc_path == NULL) || (strlen(outputfile_enc_path) == 0)) {
		strcpy((char*)outputfile_enc_path, inputfile_path);
		strcat((char*)outputfile_enc_path, ".o.data");
	}
	if (o_type == LEM_IO_TEXT)
		outputfile_enc_d = fopen(outputfile_enc_path, "w" ); 
	else	// o_type == LEM_IO_BINARY	// default
		outputfile_enc_d = fopen(outputfile_enc_path, "wb" ); 
	if (!outputfile_enc_d) {
		printf("couldn't open output file for encoded data %s\n", outputfile_enc_path);
		exit(1);
	}
	   
	if (LOG_flag) {
		if (logfile_path == NULL) {
	        strcpy((char*)logfile_path, "./idealem_log.txt");
		}
	    logfile_d = fopen(logfile_path, "a");
	    if (logfile_d) {
	        log_to_file(logfile_d, "IDEADLEM_START");
		} else {
			printf("couldn't open log file %s\n", logfile_path);
			exit(1);
		}
	}
  
// statistical data reduction for a single stream input from a text file
// for text input reading
	if (i_type == LEM_IO_TEXT)	// default
		block_size = (int)read_double(block_samples, lemblklen, inputfile_d, max_input_read);
	else	// i_type == LEM_IO_BINARY
		block_size = (int)read_double_bin(block_samples, lemblklen, inputfile_d);
	
//	while ((block_size = (int)read_double(block_samples, lemblklen, inputfile_d, max_input_read)) ) {
	while (block_size) {

        //timestep += block_size;
        //printf("timestep: %ld\n", timestep);
        if (delta) { // compute delta in reverse order
            for (i=block_size-1; i > 0; i--)
                block_samples[i] -= block_samples[i-1];
        }
        else if (residual) { // first subtract base value from every other value
            for (i=1; i < block_size; i++)
                block_samples[i] -= block_samples[0];
        }
        
        if (range) { // standardization
            double diffmax = (rangemax-rangemin)/2.0; // -diffmax < diffvalue <= diffmax
            
            for(i=1; i < block_size; i++) {
                if (block_samples[i] <= -diffmax)
                    block_samples[i] += (rangemax - rangemin);
                else if (block_samples[i] > diffmax)
                    block_samples[i] -= (rangemax - rangemin);
            }
        }
        
        
        memcpy(sorted_block, block_samples, sizeof(double)*block_size);
        // sort for a valid input to KStest()
        if (delta || residual)
            qsort(sorted_block+1, block_size-1, sizeof(double), compare);
        else
            qsort(sorted_block, block_size, sizeof(double), compare);
		
		if (partitionscnt >= partitionsnum) { // when partitions are fully populated
			for (i=0; i < partitionsnum; i++) {  // compare with existing partition(s)
                if (delta || residual) { // exchangeability test w/o base value
                    if (reltol > 0) { // min/max filter out operations
                        if (widthcheck) {
                            if ( (partitions[i].aux->minmintol > sorted_block[1]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || ( ((1-reltol)*partitions[i].aux->width) > (sorted_block[block_size-1]-sorted_block[1]) ) || ( ((1+reltol)*partitions[i].aux->width) < (sorted_block[block_size-1]-sorted_block[1]) ) )
                                continue; // continue the loop w/o KS-test if the value OR the ratio falls outside of tolerance range
                        }
                        else {
                            if ( (partitions[i].aux->minmintol > sorted_block[1]) || (partitions[i].aux->minmaxtol < sorted_block[1]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || (partitions[i].aux->maxmintol > sorted_block[block_size-1]) )
                                continue; // continue the loop w/o KS-test if the value falls outside of tolerance range
                        }
                    }
                    exchangeabilty = idealem_exchangeability_single_stream(sorted_block+1, block_size-1, partitions[i].sorted_block+1, block_size-1, alpha_threshold, &hitcntbyte);
                }
                else { // exchnageability test in normal mode
                    if (reltol > 0) { // min/max filter out operations
                        if (widthcheck) {
                            if ( (partitions[i].aux->minmintol > sorted_block[0]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || ( ((1-reltol)*partitions[i].aux->width) > (sorted_block[block_size-1]-sorted_block[0]) ) || ( ((1+reltol)*partitions[i].aux->width) < (sorted_block[block_size-1]-sorted_block[0]) ) )
                                continue;
                        }
                        else {
                            if ( (partitions[i].aux->minmintol > sorted_block[0]) || (partitions[i].aux->minmaxtol < sorted_block[0]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || (partitions[i].aux->maxmintol > sorted_block[block_size-1]) )
                                continue;
                        }
                    }
                    exchangeabilty = idealem_exchangeability_single_stream(sorted_block, block_size, partitions[i].sorted_block, block_size, alpha_threshold, &hitcntbyte);
                }
                
				if (exchangeabilty) {  // exchangeable
					partitionsidx = i;
					// text output
					if (o_type == LEM_IO_TEXT)
						write_hit_count(&partitionsidx, 1, outputfile_enc_d);
					else	// default
						write_hit_count_bin(&partitionsidx, 1, outputfile_enc_d);
                    
                    if (delta || residual) { // base value output
                        if (o_type == LEM_IO_TEXT)
                            write_double(block_samples, 1, outputfile_enc_d, precision);
                        else
                            write_double_bin(block_samples, 1, outputfile_enc_d);
                    }
                    
					break; // found LEM, no need to check remaining partition(s)
				}
			}
			if (i == partitionsnum) { // found no LEM
		        // new singleton partition on rolling basis (oldest partition is overwritten)
		        partitionsidx = 0xFF; // marker signaling overwriting
		        // FILE OUTPUT (overwrite marker)
				if (o_type == LEM_IO_TEXT)
					write_hit_count(&partitionsidx, 1, outputfile_enc_d);
				else	// default
					write_hit_count_bin(&partitionsidx, 1, outputfile_enc_d);
		        partitionsidx = partitionscnt % partitionsnum;
        
		        // Overwriting
		        memcpy(partitions[partitionsidx].block, block_samples, sizeof(double)*block_size); 
				// copy samples to the partition
		        memcpy(partitions[partitionsidx].sorted_block, sorted_block, sizeof(double)*block_size); 
				// copy sorted samples to the partition
				
                // updating
                if (delta || residual) {
                    if (reltol > 0) {
                        partitions[partitionsidx].aux->minmintol = sorted_block[1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        partitions[partitionsidx].aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        if (widthcheck) {
                            partitions[partitionsidx].aux->width = sorted_block[block_size-1] - sorted_block[1];
                        }
                        else {
                            partitions[partitionsidx].aux->minmaxtol = sorted_block[1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                            partitions[partitionsidx].aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        }
                    }
                }
                else {
                    if (reltol > 0) {
                        partitions[partitionsidx].aux->minmintol = sorted_block[0] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        partitions[partitionsidx].aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        if (widthcheck) {
                            partitions[partitionsidx].aux->width = sorted_block[block_size-1] - sorted_block[0];
                        }
                        else {
                            partitions[partitionsidx].aux->minmaxtol = sorted_block[0] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                            partitions[partitionsidx].aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        }
                    }
                }
                
		        // STREAM OUTPUT
				if (o_type == LEM_IO_TEXT) {
					write_hit_count(&partitionsidx, 1, outputfile_enc_d);
			        // CDF OUTPUT
					write_double(partitions[partitionsidx].block, lemblklen, outputfile_enc_d, precision);
				}
				else {	// default
					write_hit_count_bin(&partitionsidx, 1, outputfile_enc_d);
					write_double_bin(partitions[partitionsidx].block, lemblklen, outputfile_enc_d);
				}
				        
		        partitionscnt++;
			}
			//hitcntbyte=0;	// just reset as this is not needed here. only for 1 buffer.
		}
		else {	// when partitions are not populated yet
			for (i=0; i < partitionscnt; i++) {  // compare with existing partition(s)
				// printf("try LEM: %d\n", i);
				// printf("sorted block\n");
				// for (int j = 0; j< block_size; j++) printf ("%f ", sorted_block[j]);
				// printf("\npartition block: ");
				// for (int j = 0; j< block_size; j++) printf ("%f ", (partitions[i].sorted_block)[j]);
				// printf("\n");
                if (delta || residual) { // exchangeability test w/o base value
                    if (reltol > 0) {
                        if (widthcheck) {
                            if ( (partitions[i].aux->minmintol > sorted_block[1]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || ( ((1-reltol)*partitions[i].aux->width) > (sorted_block[block_size-1]-sorted_block[1]) ) || ( ((1+reltol)*partitions[i].aux->width) < (sorted_block[block_size-1]-sorted_block[1]) ) )
                                continue; // continue the loop w/o KS-test if the value OR the ratio falls outside of tolerance range
                        }
                        else {
                            if ( (partitions[i].aux->minmintol > sorted_block[1]) || (partitions[i].aux->minmaxtol < sorted_block[1]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || (partitions[i].aux->maxmintol > sorted_block[block_size-1]) )
                                continue; // continue the loop w/o KS-test if the value falls outside of tolerance range
                        }
                    }
                    exchangeabilty = idealem_exchangeability_single_stream(sorted_block+1, block_size-1, partitions[i].sorted_block+1, block_size-1, alpha_threshold, &hitcntbyte);
                }
                else { // exchnageability test in normal mode
                    if (reltol > 0) { // min/max filter out operations
                        if (widthcheck) {
                            if ( (partitions[i].aux->minmintol > sorted_block[0]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || ( ((1-reltol)*partitions[i].aux->width) > (sorted_block[block_size-1]-sorted_block[0]) ) || ( ((1+reltol)*partitions[i].aux->width) < (sorted_block[block_size-1]-sorted_block[0]) ) )
                                continue;
                        }
                        else {
                            if ( (partitions[i].aux->minmintol > sorted_block[0]) || (partitions[i].aux->minmaxtol < sorted_block[0]) || (partitions[i].aux->maxmaxtol < sorted_block[block_size-1]) || (partitions[i].aux->maxmintol > sorted_block[block_size-1]) )
                                continue;
                        }
                    }
                    exchangeabilty = idealem_exchangeability_single_stream(sorted_block, block_size, partitions[i].sorted_block, block_size, alpha_threshold, &hitcntbyte);
                }
                
				if (exchangeabilty) {  // exchangeable
					partitionsidx = i;
					if (o_type == LEM_IO_TEXT)
						write_hit_count(&partitionsidx, 1, outputfile_enc_d);
					else	// default
						write_hit_count_bin(&partitionsidx, 1, outputfile_enc_d);
                    
                    if (delta || residual) { // base value output
                        if (o_type == LEM_IO_TEXT)
                            write_double(block_samples, 1, outputfile_enc_d, precision);
                        else
                            write_double_bin(block_samples, 1, outputfile_enc_d);
                    }
                    
					break; // found LEM, no need to check remaining partition(s)
				}
			}
	        if (i == partitionscnt) { // found no LEM or there's no partition initially
				// above for loop not even executed
				// new singleton partition
				partitionsidx = partitionscnt;
				memcpy(partitions[partitionsidx].block, block_samples, sizeof(double)*block_size); 
				// copy samples to the partition
				memcpy(partitions[partitionsidx].sorted_block, sorted_block, sizeof(double)*block_size); 
				// copy sorted samples to the partition
                
                // updating
                if (delta || residual) {
                    if (reltol > 0) {
                        partitions[partitionsidx].aux->minmintol = sorted_block[1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        partitions[partitionsidx].aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        if (widthcheck) {
                            partitions[partitionsidx].aux->width = sorted_block[block_size-1] - sorted_block[1];
                        }
                        else {
                            partitions[partitionsidx].aux->minmaxtol = sorted_block[1] + ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                            partitions[partitionsidx].aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[1])*reltol);
                        }
                    }
                }
                else {
                    if (reltol > 0) {
                        partitions[partitionsidx].aux->minmintol = sorted_block[0] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        partitions[partitionsidx].aux->maxmaxtol = sorted_block[block_size-1] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        if (widthcheck) {
                            partitions[partitionsidx].aux->width = sorted_block[block_size-1] - sorted_block[0];
                        }
                        else {
                            partitions[partitionsidx].aux->minmaxtol = sorted_block[0] + ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                            partitions[partitionsidx].aux->maxmintol = sorted_block[block_size-1] - ((sorted_block[block_size-1]-sorted_block[0])*reltol);
                        }
                    }
                }
        
		        // STREAM OUTPUT
				if (o_type == LEM_IO_TEXT) {
					write_hit_count(&partitionsidx, 1, outputfile_enc_d);
			        // CDF OUTPUT
					write_double(partitions[partitionsidx].block, lemblklen, outputfile_enc_d, precision);
				}
				else {	// default
					write_hit_count_bin(&partitionsidx, 1, outputfile_enc_d);
					write_double_bin(partitions[partitionsidx].block, lemblklen, outputfile_enc_d);
				}

				partitionscnt++;
	        }
			//hitcntbyte=0;	// just reset as this is not needed here. only for 1 buffer.
		}
		
		if (i_type == LEM_IO_TEXT)	// default
			block_size = (int)read_double(block_samples, lemblklen, inputfile_d, max_input_read);
		else
			block_size = (int)read_double_bin(block_samples, lemblklen, inputfile_d);
		
		// printf("partitions count: %d\n", partitionscnt);
    }
        
    fclose(inputfile_d);
    fclose(outputfile_enc_d);
    if (LOG_flag) fclose(logfile_d);
    
    return 0;
}

//  
//  DECODING
//  statistical data restore from the encoded data for testing purpose
int idealem_file_stream_decoding(const char* inputfile_path, const char* outputfile_dec_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax) {

	FILE* inputfile_d;
    FILE* outputfile_dec_d;
    FILE* logfile_d = NULL;
	//time_t tid;
	
    size_t block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen

	double* block_samples;  // sample block array
	//long timestep = 0; // time step for debugging  purpose only
	unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits 
		// with previous buffer to be written to the output

	block_samples = (double*)alloca(sizeof(double)*lemblklen);
    hitcntbyte = 0; // counter to keep track of # of hits with previous buffer
    
    int i, j; // for loop index
    double* basevals; // base values store
    double* valrecover;
    basevals = (double*)alloca(sizeof(double)*max_hit_count);
    valrecover = (double*)alloca(sizeof(double)*lemblklen);
    
	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	if (i_type == LEM_IO_TEXT)
		inputfile_d = fopen(inputfile_path, "r" );
	else	// i_type==LEM_IO_BINARY	// default
		inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file from encoded data %s\n", inputfile_path);
		exit(1);
	}

	if ((outputfile_dec_path == NULL) || (strlen(outputfile_dec_path) == 0)) {
		strcpy((char*)outputfile_dec_path, inputfile_path);
		strcat((char*)outputfile_dec_path, ".o.data");
	}
	if (o_type == LEM_IO_TEXT)	// default
		outputfile_dec_d = fopen(outputfile_dec_path, "w" );
	else	// o_type==LEM_IO_BINARY
		outputfile_dec_d = fopen(outputfile_dec_path, "wb" );
	if (!outputfile_dec_d) {
		printf("couldn't open output file for decoded data %s\n", outputfile_dec_path);
		exit(1);
	}
	
	if (LOG_flag) {
		if (logfile_path == NULL) {
	        strcpy((char*)logfile_path, "./idealem_log.txt");
		}
	    logfile_d = fopen(logfile_path, "a");
	    if (logfile_d) {
	        log_to_file(logfile_d, "IDEADLEM_START");
		} else {
			printf("couldn't open log file %s\n", logfile_path);
			exit(1);
		}
	}
    
    // Intializes random number generator
	//srand((unsigned)time(&tid));
    
	if (i_type == LEM_IO_TEXT)
		block_size = read_double(block_samples, lemblklen, inputfile_d, max_input_read);
	else	// i_type==LEM_IO_BINARY	// default
		block_size = read_double_bin(block_samples, lemblklen, inputfile_d);
//    while (read_double(block_samples, lemblklen, inputfile_d, max_input_read)) {
    while (block_size) {
			// read new CDF to fresh buffer until end of the stream
		if (i_type == LEM_IO_TEXT)
			read_hit_count(&hitcntbyte, 1, inputfile_d, max_input_read);
		else	// default
			read_hit_count_bin(&hitcntbyte, 1, inputfile_d);
        
        if (delta || residual) { // delta/residual mode
            if (hitcntbyte) {
                if (i_type == LEM_IO_TEXT)
                    (void)read_double(basevals, hitcntbyte, inputfile_d, max_input_read);
                else
                    (void)read_double_bin(basevals, hitcntbyte, inputfile_d);
            }
            
            valrecover[0] = block_samples[0]; // base value
            if (delta) { // delta recovery
                for (i=1; i < lemblklen; i++)
                    valrecover[i] = valrecover[i-1] + block_samples[i];
            }
            else { // residual recovery
                for (i=1; i < lemblklen; i++)
                    valrecover[i] = block_samples[0] + block_samples[i];
            }
            
            if (range) { // ensure values are within the range of min to max
                for (i=0; i < lemblklen; i++) {
                    if (valrecover[i] < rangemin)
                        valrecover[i] += (rangemax - rangemin);
                    else if (valrecover[i] >= rangemax)
                        valrecover[i] -= (rangemax - rangemin);
                }
            }
            
            if (o_type == LEM_IO_TEXT) // file output
                (void)write_double(valrecover, lemblklen, outputfile_dec_d, precision);
            else
                (void)write_double_bin(valrecover, lemblklen, outputfile_dec_d);
            
            for (i=0; i < hitcntbyte; i++) {
                valrecover[0] = basevals[i]; // base value
                if (delta) { // delta recovery
                    for (j=1; j < lemblklen; j++)
                        valrecover[j] = valrecover[j-1] + block_samples[j];
                }
                else { // residual recovery
                    for (j=1; j < lemblklen; j++)
                        valrecover[j] = basevals[i] + block_samples[j];
                }
                
                if (range) {
                    for (j=0; j < lemblklen; j++) {
                        if (valrecover[j] < rangemin)
                            valrecover[j] += (rangemax-rangemin);
                        else if (valrecover[j] >= rangemax)
                            valrecover[j] -= (rangemax-rangemin);
                    }
                }
                
                if (o_type == LEM_IO_TEXT) // file output
                    (void)write_double(valrecover, lemblklen, outputfile_dec_d, precision);
                else
                    (void)write_double_bin(valrecover, lemblklen, outputfile_dec_d);
            }
            
        }
        else { // normal mode
            if (o_type == LEM_IO_TEXT) {	// default
                write_double(block_samples, lemblklen, outputfile_dec_d, precision);
                permuted_output(hitcntbyte, block_samples, lemblklen, outputfile_dec_d, precision);
                // output when the stream has repetitions to previous buffers
            }
            else {
                write_double_bin(block_samples, lemblklen, outputfile_dec_d);
                // file output as is for values stored in buffer
                permuted_output_bin(hitcntbyte, block_samples, lemblklen, outputfile_dec_d);
                // output when the stream has repetitions to previous buffers
            }
        }
        //timestep += lemblklen * (hitcntbyte+1); // increase timestep
        
        while (hitcntbyte == max_hit_count) { 
			// if hit count equals to max_hit_count
			if (i_type == LEM_IO_TEXT)
				read_hit_count(&hitcntbyte, 1, inputfile_d, max_input_read); // read again
			else	// default
				read_hit_count_bin(&hitcntbyte, 1, inputfile_d);
            
            if (delta || residual) { // delta/residual mode
                if (hitcntbyte) {
                    if (i_type == LEM_IO_TEXT)
                        (void)read_double(basevals, hitcntbyte, inputfile_d, max_input_read);
                    else
                        (void)read_double_bin(basevals, hitcntbyte, inputfile_d);
                }
                
                for (i=0; i < hitcntbyte; i++) {
                    valrecover[0] = basevals[i]; // base value
                    if (delta) { // delta recovery
                        for (j=1; j < lemblklen; j++)
                            valrecover[j] = valrecover[j-1] + block_samples[j];
                    }
                    else { // residual recovery
                        for (j=1; j < lemblklen; j++)
                            valrecover[j] = basevals[i] + block_samples[j];
                    }
                    
                    if (range) {
                        for (j=0; j < lemblklen; j++) {
                            if (valrecover[j] < rangemin)
                                valrecover[j] += (rangemax-rangemin);
                            else if (valrecover[j] >= rangemax)
                                valrecover[j] -= (rangemax-rangemin);
                        }
                    }
                    
                    if (o_type == LEM_IO_TEXT) // file output
                        (void)write_double(valrecover, lemblklen, outputfile_dec_d, precision);
                    else
                        (void)write_double_bin(valrecover, lemblklen, outputfile_dec_d);
                }
                
            }
            else { // normal mode
                if (o_type == LEM_IO_TEXT) 	// default
                    permuted_output(hitcntbyte, block_samples, lemblklen, outputfile_dec_d, precision);
                // output when the stream has repetitions to previous buffers
                else
                    permuted_output_bin(hitcntbyte, block_samples, lemblklen, outputfile_dec_d);
            }
			 	
            //timestep += lemblklen*hitcntbyte; // increase timestep
        }
		
		if (i_type == LEM_IO_TEXT)
			block_size = read_double(block_samples, lemblklen, inputfile_d, max_input_read);
		else	// i_type==LEM_IO_BINARY	// default
			block_size = read_double_bin(block_samples, lemblklen, inputfile_d);
    }

    fclose(inputfile_d);
    fclose(outputfile_dec_d);
    if (LOG_flag) fclose(logfile_d);

	return 0;
}

//  
//  DECODING for multiple variables including time stamps
//  statistical data restore from the encoded data for testing purpose
int idealem_file_stream_decoding_multivars(const char* inputfile_path, const char* outputfile_dec_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int colno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type) {

	FILE* inputfile_d;
    FILE* outputfile_dec_d;
    FILE* logfile_d = NULL;
	//time_t tid;

    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen
	
	double* block_samples;  // sample block array
	long timestep = 0;
	unsigned char hitcntbyte = 0; 
		// count to keep track of number of hits 
		// with previous buffer to be written to the output

    char** line_samples;  // sample block array for lines
	int i=0; // index for loop

    line_samples = (char **)malloc(lemblklen * sizeof(char *));
    for (i=0; i<lemblklen; i++)
		line_samples[i] = (char *)malloc(max_input_read * sizeof(char));

	block_samples = (double*)alloca(sizeof(double)*lemblklen);
    timestep = 0;  // time step for debugging  purpose only
    hitcntbyte = 0; // counter to keep track of # of hits with previous buffer
    
	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	if (i_type == LEM_IO_TEXT)
		inputfile_d = fopen(inputfile_path, "r" );
	else	// i_type == LEM_IO_BINARY	// default
		inputfile_d = fopen(inputfile_path, "r" );	// rb
	// FIX r later. encoding multivar is not ready
	if (!inputfile_d) {
		printf("couldn't open input file from encoded data %s\n", inputfile_path);
		exit(1);
	}

	if ((outputfile_dec_path == NULL) || (strlen(outputfile_dec_path) == 0)) {
		strcpy((char*)outputfile_dec_path, inputfile_path);
		strcat((char*)outputfile_dec_path, ".o.data");
	}
	if (o_type == LEM_IO_TEXT)	// default
		outputfile_dec_d = fopen(outputfile_dec_path, "w" );
	else
		outputfile_dec_d = fopen(outputfile_dec_path, "wb" );
	if (!outputfile_dec_d) {
		printf("couldn't open output file for decoded data %s\n", outputfile_dec_path);
		exit(1);
	}
	
	if (LOG_flag) {
		if (logfile_path == NULL) {
	        strcpy((char*)logfile_path, "./idealem_log.txt");
		}
	    logfile_d = fopen(logfile_path, "a");
	    if (logfile_d) {
	        log_to_file(logfile_d, "IDEADLEM_START");
		} else {
			printf("couldn't open log file %s\n", logfile_path);
			exit(1);
		}
	}
    
    // Intializes random number generator
	//srand((unsigned)time(&tid));

	if (i_type == LEM_IO_TEXT)
		block_size = read_double_in_multivars(line_samples, colno, block_samples, lemblklen, inputfile_d, max_input_read);
	else	// default
		block_size = read_double_in_multivars_bin(line_samples, colno, block_samples, lemblklen, inputfile_d, max_input_read);
	
    while (block_size) {
			// read new CDF to fresh buffer until end of the stream
		if (i_type == LEM_IO_TEXT)
			read_hit_count(&hitcntbyte, 1, inputfile_d, max_input_read);
		else	// default
			read_hit_count(&hitcntbyte, 1, inputfile_d, max_input_read);
		// FIX later to read_hit_count_bin
        /*
        for (i=0; i < lemblklen; i++)
            printf("%f\n", prevbuffer.blk[i]); // print floating values stored in buffer
		*/
	
        //write_double(block_samples, lemblklen, outputfile_dec_d); 
			// file output as is for values stored in buffer
		if (o_type == LEM_IO_TEXT) {	// default
			write_multivars(line_samples, lemblklen, outputfile_dec_d);
			permuted_output_in_multivars(hitcntbyte, line_samples, lemblklen, outputfile_dec_d); 
		}
		else {
			write_multivars_bin(line_samples, lemblklen, outputfile_dec_d);
			permuted_output_in_multivars_bin(hitcntbyte, line_samples, lemblklen, outputfile_dec_d); 
		}
        
        //permuted_output(hitcntbyte, block_samples, lemblklen, outputfile_dec_d); 
			// output when the stream has repetitions to previous buffers
        timestep += lemblklen * (hitcntbyte+1); // increase timestep

		
        while (hitcntbyte == max_hit_count) { 
			// if hit count equals to max_hit_count
			if (i_type == LEM_IO_TEXT)
				read_hit_count(&hitcntbyte, 1, inputfile_d, max_input_read); // read again
			else	// default
				read_hit_count_bin(&hitcntbyte, 1, inputfile_d);
			if (o_type == LEM_IO_TEXT)	// default
				permuted_output_in_multivars(hitcntbyte, line_samples, lemblklen, outputfile_dec_d); 
			else
				permuted_output_in_multivars_bin(hitcntbyte, line_samples, lemblklen, outputfile_dec_d); 
			//permuted_output(hitcntbyte, block_samples, lemblklen, outputfile_dec_d); 
				// output when the stream has repetitions to previous buffers
            timestep += lemblklen*hitcntbyte; // increase timestep
        }
    }

    fclose(inputfile_d);
    fclose(outputfile_dec_d);
    if (LOG_flag) fclose(logfile_d);

	return 0;
}

//  
//  DECODING with historical buffers
//  statistical data restore from the encoded data for testing purpose
int idealem_file_stream_decoding_with_history(const char* inputfile_path, const char* outputfile_dec_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, int bufferno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax) {

	FILE* inputfile_d;

    int block_size;
    	// read each timeseries data from a stream 
		// block_size should equal to lemblklen
	
    int overwrite = 0;  // overwrite flag
    //long timestep = 0;  // time step
    unsigned char partitionsidx;  // partitions index to be read from input file
    unsigned char partitionscnt = 0;  
		// partition cnt to keep track of, 
		// no longer increases when it reaches partitionsnum
	int partitionsnum = bufferno; // number of historical buffers, default=1
    LEM_BLOCK* partitions;
	
    FILE* outputfile_dec_d;
    FILE* logfile_d = NULL;
	//time_t tid;

	double* block_samples;  // sample block array
	int i=0; // index for loop
    
    double* valrecover; // for residual/delta mode
    valrecover = (double*)alloca(sizeof(double)*lemblklen);

    partitions = (LEM_BLOCK*)alloca(sizeof(LEM_BLOCK)*partitionsnum);
    for (i=0; i < partitionsnum; i++) {
		partitions[i].block = (double*)alloca(sizeof(double)*lemblklen);
		partitions[i].count = 0;
	}
	
	block_samples = (double*)alloca(sizeof(double)*lemblklen);

    
	if (inputfile_path == NULL) {
		printf("couldn't open input file %s\n", inputfile_path);
		exit(1);
	}
	if (i_type == LEM_IO_TEXT)
		inputfile_d = fopen(inputfile_path, "r" );
	else	// i_type==LEM_IO_BINARY	//default
		inputfile_d = fopen(inputfile_path, "rb" );
	if (!inputfile_d) {
		printf("couldn't open input file from encoded data %s\n", inputfile_path);
		exit(1);
	}
	
	if ((outputfile_dec_path == NULL) || (strlen(outputfile_dec_path) == 0)) {
		strcpy((char*)outputfile_dec_path, inputfile_path);
		strcat((char*)outputfile_dec_path, ".o.data");
	}
	if (o_type == LEM_IO_TEXT)	// default
		outputfile_dec_d = fopen(outputfile_dec_path, "w" ); 
	else
		outputfile_dec_d = fopen(outputfile_dec_path, "wb" ); 
	if (!outputfile_dec_d) {
		printf("couldn't open output file for decoded data %s\n", outputfile_dec_path);
		exit(1);
	}
	
	if (LOG_flag) {
		if (logfile_path == NULL) {
	        strcpy((char*)logfile_path, "./idealem_log.txt");
		}
	    logfile_d = fopen(logfile_path, "a");
	    if (logfile_d) {
	        log_to_file(logfile_d, "IDEADLEM_START");
		} else {
			printf("couldn't open log file %s\n", logfile_path);
			exit(1);
		}
	}
    
    // Intializes random number generator
    //srand((unsigned)time(NULL));
	//srand((unsigned)time(&tid));
    
    while (1) {
		if (i_type == LEM_IO_TEXT)
			block_size = read_hit_count(&partitionsidx, 1, inputfile_d, max_input_read);
		else
			block_size = read_hit_count_bin(&partitionsidx, 1, inputfile_d);
		if ( !block_size ) {
			// printf("end of the input file\n");
			break;
		}
		if (partitionscnt == partitionsnum) { // when partitions are fully populated
			if (overwrite) {
				// read new CDF from CDF FILE and overwrite existing partition
				if (i_type == LEM_IO_TEXT)
					read_double(partitions[partitionsidx].block, lemblklen, inputfile_d, max_input_read);
				else	// default
					read_double_bin(partitions[partitionsidx].block, lemblklen, inputfile_d);
				partitions[partitionsidx].count = 0; // reset counter
				overwrite = 0; // reset the flag
			}
			else if (partitionsidx == 0xFF) { // overwriting marker
				overwrite = 1;  // raise the flag
				continue; // and continue
			}
		}
		else if (partitionscnt == partitionsidx) { 
			// when partitions are not populated yet and encounters new partition
			// read new CDF from CDF FILE to fresh partition
			if (i_type == LEM_IO_TEXT)
				read_double(partitions[partitionsidx].block, lemblklen, inputfile_d, max_input_read);
			else	// default
				read_double_bin(partitions[partitionsidx].block, lemblklen, inputfile_d);
			partitionscnt++;
		}
        
        if (delta || residual) { // delta/residual mode
            if (partitions[partitionsidx].count) { // if this is the repeated use case of lemblk
                if (i_type == LEM_IO_TEXT) // no random shuffle, but replace base value
                    (void)read_double(partitions[partitionsidx].block, 1, inputfile_d, max_input_read);
                else
                    (void)read_double_bin(partitions[partitionsidx].block, 1, inputfile_d);
            }
            else { // the first use case
                partitions[partitionsidx].count++;
            }
            
            if (o_type == LEM_IO_TEXT)	// default
                deltaresidual_output_cdf(partitions, partitionsidx, lemblklen, outputfile_dec_d, precision, valrecover, delta, range, rangemin, rangemax);
            else
                deltaresidual_output_cdf_bin(partitions, partitionsidx, lemblklen, outputfile_dec_d, valrecover, delta, range, rangemin, rangemax);
        }
        else {  // normal mode
            if (o_type == LEM_IO_TEXT)	// default
                permuted_output_cdf(partitions, partitionsidx, lemblklen, outputfile_dec_d, precision);
            else
                permuted_output_cdf_bin(partitions, partitionsidx, lemblklen, outputfile_dec_d);
        }
		
        //timestep += lemblklen;
    }
	
	fclose(inputfile_d);
    fclose(outputfile_dec_d);
    if (LOG_flag) fclose(logfile_d);
	
	return 0;
}

#endif  // _ENABLE_CXX_IDEALEM

bool acmp(const char* left, const char* right) {
    if (strcmp(left, right))
        return false;
    return true;
}
