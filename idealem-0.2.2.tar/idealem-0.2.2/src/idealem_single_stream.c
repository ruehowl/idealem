/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * Last updated on Thu Mar  3 00:07:12 PST 2016
 *
 */
//
// idealem_single_stream.c
// LEM encoder for a single stream
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//#include <idealem_const.h>
#include <idealem_common.h>
#include <idealem_util.h>

#ifdef _ENABLE_CXX_IDEALEM 	// C++ API

IDEALEM_SINGLE_STREAM::IDEALEM_SINGLE_STREAM(int lemblocklen, double alphathreshold, bool encoding) {
	ENCODING_flag=encoding;
	inputfile_path=NULL;
    outputfile_path=NULL;
    logfile_path=NULL;
    LOG_flag=false;
    DEBUG_flag=false;
    lemblklen=16;
    alpha_threshold=0.05;
    max_hit_count=255;
    max_input_read=1024;
	hit_count=0;
	precision=10;

	lemblklen = lemblocklen;
	alpha_threshold = alphathreshold;
	var_column = -1;
	multivars=false;
	history_buffer=1;
	if (ENCODING_flag) {
		i_type = LEM_IO_TEXT;	// default for encoding
		o_type = LEM_IO_BINARY;	// default for encoding
	}
	else {
		i_type = LEM_IO_BINARY;	// default for decoding
		o_type = LEM_IO_TEXT;	// default for decoding
	}
}

IDEALEM_SINGLE_STREAM::~IDEALEM_SINGLE_STREAM() {
	fclose(inputfile_d);
    if (get_outputfile_path() != NULL) fclose(outputfile_d);
    if (LOG_flag) fclose(logfile_d);

}

bool IDEALEM_SINGLE_STREAM::init_for_files(const char* inputfilepath, const char* outputfilepath, LEM_IO_TYPE_T itype, LEM_IO_TYPE_T otype, int maxhitcount, int maxinputread, int tprecision, int varcolumn, int historybuffer) {
	i_type = itype;
	o_type = otype;

	if (inputfilepath == NULL) {
        printf("couldn't open input file %s\n", inputfilepath);
        exit(1);
    }
	inputfile_path = inputfilepath;
	if (i_type == LEM_IO_TEXT)
		inputfile_d = fopen(inputfile_path, "r" );
	else // i_type==LEM_IO_BINARY
		inputfile_d = fopen(inputfile_path, "rb" );
    if (!inputfile_d) {
        printf("couldn't open input file %s\n", inputfile_path);
        exit(1);
    }

	if ((outputfilepath == NULL) || (strlen(outputfilepath) == 0)) {
        strcpy((char*)outputfilepath, inputfile_path);
        strcat((char*)outputfilepath, ".o.data");
    }
	outputfile_path = outputfilepath;
	if (o_type == LEM_IO_TEXT) {
    	outputfile_d = fopen(outputfile_path, "w" );
	}
	else {	// o_type == LEM_IO_BINARY
		outputfile_d = fopen(outputfile_path, "wb" );
	}
    if (!outputfile_d) {
        printf("couldn't open output file for encoded data %s\n", outputfile_path);
        exit(1);
    }

	max_hit_count = maxhitcount;
	max_input_read = maxinputread;
	hit_count=0;
	var_column = varcolumn;
	precision = tprecision;
	if (var_column >= 0) multivars=true;
	history_buffer = historybuffer;
	//block_samples = (double*)alloca(sizeof(double)*lemblklen);

	return true;
}

bool IDEALEM_SINGLE_STREAM::init_for_files(const char* inputfilepath, const char* outputfilepath, int maxhitcount, int maxinputread, int tprecision, int varcolumn, int historybuffer) {
	if (inputfilepath == NULL) {
        printf("couldn't open input file %s\n", inputfilepath);
        exit(1);
    }
	inputfile_path = inputfilepath;
	if (i_type == LEM_IO_TEXT)
		inputfile_d = fopen(inputfile_path, "r" );
	else // i_type==LEM_IO_BINARY
		inputfile_d = fopen(inputfile_path, "rb" );
    if (!inputfile_d) {
        printf("couldn't open input file %s\n", inputfile_path);
        exit(1);
    }

	if ((outputfilepath == NULL) || (strlen(outputfilepath) == 0)) {
        strcpy((char*)outputfilepath, inputfile_path);
        strcat((char*)outputfilepath, ".o.data");
    }
	outputfile_path = outputfilepath;
	if (o_type == LEM_IO_TEXT) {
    	outputfile_d = fopen(outputfile_path, "w" );
	}
	else {	// o_type == LEM_IO_BINARY
		outputfile_d = fopen(outputfile_path, "wb" );
	}
    if (!outputfile_d) {
        printf("couldn't open output file for encoded data %s\n", outputfile_path);
        exit(1);
    }

	max_hit_count = maxhitcount;
	max_input_read = maxinputread;
	hit_count=0;
	var_column = varcolumn;
	precision = tprecision;
	if (var_column >= 0) multivars=true;
	history_buffer = historybuffer;
	//block_samples = (double*)alloca(sizeof(double)*lemblklen);

	return true;
}

bool IDEALEM_SINGLE_STREAM::set_inputfile_path(const char* inputfilepath) {
	if (inputfilepath == NULL) {
        printf("couldn't open input file %s\n", inputfilepath);
        exit(1);
    }
    inputfile_path = inputfilepath;
    inputfile_d = fopen(inputfile_path, "r" );
    if (!inputfile_d) {
        printf("couldn't open input file %s\n", inputfile_path);
        exit(1);
    }

	return true;
}

const char* IDEALEM_SINGLE_STREAM::get_inputfile_path() {
    return inputfile_path;
}

bool IDEALEM_SINGLE_STREAM::set_outputfile_path(const char* outputfilepath) {
	if ((outputfilepath == NULL) || (strlen(outputfilepath) == 0)) {
        strcpy((char*)outputfilepath, inputfile_path);
        strcat((char*)outputfilepath, ".o.data");
    }
    outputfile_path = outputfilepath;
    outputfile_d = fopen(outputfile_path, "w" );
    if (!outputfile_d) {
        printf("couldn't open output file for encoded data %s\n", outputfile_path);
        exit(1);
    }

	return true;
}

const char* IDEALEM_SINGLE_STREAM::get_outputfile_path() {
    return outputfile_path;
}

bool IDEALEM_SINGLE_STREAM::set_logfile_path(const char* logfilepath) {
	if (logfilepath == NULL) {
        strcpy((char*)logfile_path, "./idealem_log.txt");
    }
	else {
		logfile_path = logfilepath;
	}
    logfile_d = fopen(logfile_path, "a");
    if (logfile_d) {
        log_to_file(logfile_d, "IDEADLEM_START");
    } else {
        printf("couldn't open log file %s\n", logfile_path);
        exit(1);
    }
    LOG_flag=true;
	return true;
}

const char* IDEALEM_SINGLE_STREAM::get_logfile_path() {
    return logfile_path;
}

bool IDEALEM_SINGLE_STREAM::isLog(){
	return LOG_flag;
}

bool IDEALEM_SINGLE_STREAM::set_debug(bool debugflag) {
	DEBUG_flag = debugflag;
	return debugflag;
}

bool IDEALEM_SINGLE_STREAM::isDebug() {
	return DEBUG_flag;
}

bool IDEALEM_SINGLE_STREAM::isEncoding() {
	return ENCODING_flag;
}
LEM_IO_TYPE_T IDEALEM_SINGLE_STREAM::set_input_type(LEM_IO_TYPE_T itype) {
	i_type = itype;
	return i_type;
}
LEM_IO_TYPE_T IDEALEM_SINGLE_STREAM::get_input_type() {
	return i_type;
}
LEM_IO_TYPE_T IDEALEM_SINGLE_STREAM::set_output_type(LEM_IO_TYPE_T otype) {
	o_type = otype;
	return o_type;
}
LEM_IO_TYPE_T IDEALEM_SINGLE_STREAM::get_output_type() {
	return o_type;
}

int IDEALEM_SINGLE_STREAM::set_lem_block_size(int lemblocklen) {
	lemblklen = lemblocklen;
	return lemblklen;
}

int IDEALEM_SINGLE_STREAM::get_lem_block_size() {
    return lemblklen;
}

double IDEALEM_SINGLE_STREAM::set_alpha_threshold(double alphathreshold) {
	alpha_threshold = alphathreshold;
	return alpha_threshold;
}

double IDEALEM_SINGLE_STREAM::get_alpha_threshold() {
	return alpha_threshold;
}

int IDEALEM_SINGLE_STREAM::set_max_hit_count(int maxhitcount) {
    max_hit_count=maxhitcount;
	return max_hit_count;
}

int IDEALEM_SINGLE_STREAM::get_max_hit_count() {
	return max_hit_count;
}

int IDEALEM_SINGLE_STREAM::set_precision(int tprecision) {
    precision=tprecision;
	return precision;
}

int IDEALEM_SINGLE_STREAM::get_precision() {
	return precision;
}

int IDEALEM_SINGLE_STREAM::set_max_input_read(int maxinputread) {
	max_input_read = maxinputread;
	return max_input_read;
}

int IDEALEM_SINGLE_STREAM::get_max_input_read() {
	return max_input_read;
}

int IDEALEM_SINGLE_STREAM::set_var_column(int varcolumn) {
	var_column = varcolumn;
	return var_column;
}

int IDEALEM_SINGLE_STREAM::get_var_column() {
	return var_column;
}

int IDEALEM_SINGLE_STREAM::set_history_buffer(int historybuffer) {
	history_buffer = historybuffer;
	return history_buffer;
}

int IDEALEM_SINGLE_STREAM::get_history_buffer() {
	return history_buffer;
}

bool IDEALEM_SINGLE_STREAM::get_exchangeability(double* sorted_block, int sorted_block_size, double* prev_sorted_block, int prev_sorted_block_size) {
    bool exchangeability_flag=false;
    double kstestprob;  // KS Test return value

    kstestprob=KStest(sorted_block, sorted_block_size, prev_sorted_block, prev_sorted_block_size);
    //printf("kstest=%lf\n", kstestprob);
    if (kstestprob == -1) printf("kstestprob is -1\n");
    if (kstestprob >= alpha_threshold) {  // exchangeable
        hit_count++;
        exchangeability_flag=true;
    }
    else {
        exchangeability_flag=false;
    }
    //printf("hitcount=%d\n", (int) *hitcount);

    return exchangeability_flag;
}

bool IDEALEM_SINGLE_STREAM::encoding() {

// ENCODING
// statistical data reduction for a single stream input from a text file
// 
	int block_size, sorted_block_size, prev_sorted_block_size;
	long timestep=0;
	bool buffered=false;
	double* block_samples = (double*)alloca(sizeof(double)*lemblklen);
    double* sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    double* prev_sorted_block = (double*)alloca(sizeof(double)*lemblklen);

    while ((block_size = read_double(block_samples, lemblklen, inputfile_d)) ) {

        timestep += block_size;
        //printf("timestep: %ld\n", timestep);

        memcpy(sorted_block, block_samples, sizeof(double)*block_size);
        //if (!buffered) {
		//	printf("0 first block %d %d\n", block_size, lemblklen);
		//	for (int k=0; k<block_size; k++) printf("%d=%lf=%lf\n", k, *(block_samples+k), *(sorted_block+k));
		//}
		sorted_block_size = block_size;
        qsort(sorted_block, block_size, sizeof(double), compare);
            // sort for a valid input to KStest()

        if (buffered) {
            // when buffer is non-empty for all cases except initial one
            if (get_exchangeability(sorted_block, block_size, prev_sorted_block, block_size)) {  // exchangeable
                if (hit_count == max_hit_count) { // if hit count reaches max_hit_count
                    write_hit_count(hit_count, outputfile_d); // hit count
                    hit_count=0;
                }
                //printf("exc max_hit_count: %d\n", hit_count);
            }
            else { // non-exchangeable
                write_hit_count(hit_count, outputfile_d); // hit count
                hit_count=0;
                memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size);
				prev_sorted_block_size = block_size;
                    // copy sorted samples to previous sorted block
                write_double(block_samples, lemblklen, outputfile_d); // CDF OUTPUT
                //printf("non-exc max_hit_count: %d\n", hit_count);
            }
        }
        else { // when buffer is empty, the initial case
            memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size);
			prev_sorted_block_size = block_size;
                // copy sorted sample blk  to previous sorted block
            write_double(block_samples, lemblklen, outputfile_d); // CDF OUTPUT
            buffered=true; // now we have previous buffer
        }
    }

    // for the last sample data
    write_hit_count(hit_count, outputfile_d); // hit count

	return true;
}

bool IDEALEM_SINGLE_STREAM::encoding_multivars() {

// ENCODING
// statistical data reduction for a single stream input with multiple variables from a text file
// 
	int block_size, sorted_block_size, prev_sorted_block_size;
	bool buffered=false;
	long timestep=0;
    char** line_samples = (char **)malloc(lemblklen * sizeof(char *));
    for (int i=0; i<lemblklen; i++)
		line_samples[i] = (char *)malloc(max_input_read * sizeof(char));
    char** lastline_samples = (char **)malloc(lemblklen * sizeof(char *));
    for (int i=0; i<lemblklen; i++)
		lastline_samples[i] = (char *)malloc(max_input_read * sizeof(char));
	double* block_samples = (double*)alloca(sizeof(double)*lemblklen);
    double* sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    double* prev_sorted_block = (double*)alloca(sizeof(double)*lemblklen);

//    while ((block_size = read_double(block_samples, lemblklen, inputfile_d)) ) {
    while ((block_size = read_double_in_multivars(line_samples, block_samples, lemblklen, inputfile_d)) ) {

        timestep += block_size;
        //printf("timestep: %ld\n", timestep);

        memcpy(sorted_block, block_samples, sizeof(double)*block_size);
        //if (!buffered) {
		//	printf("0 first block %d %d\n", block_size, lemblklen);
		//	for (int k=0; k<block_size; k++) printf("%d=%lf=%lf\n", k, *(block_samples+k), *(sorted_block+k));
		//}
		sorted_block_size = block_size;
        qsort(sorted_block, block_size, sizeof(double), compare);
            // sort for a valid input to KStest()

		// check this last line buffer and see if it can be relocated somewhere below
	    for (int i=0; i<lemblklen; i++)
			memcpy(lastline_samples[i], line_samples[i], sizeof(char)*max_input_read);

        if (buffered) {
            // when buffer is non-empty for all cases except initial one
            if (get_exchangeability(sorted_block, block_size, prev_sorted_block, block_size)) {  // exchangeable
                if (hit_count == max_hit_count) { // if hit count reaches max_hit_count
                    write_hit_count(hit_count, outputfile_d); // hit count
                    hit_count=0;
                }
                //printf("exc max_hit_count: %d\n", hit_count);
            }
            else { // non-exchangeable
                write_hit_count(hit_count, outputfile_d); // hit count
                hit_count=0;
                memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size);
				prev_sorted_block_size = block_size;
                    // copy sorted samples to previous sorted block
                write_multivars(line_samples, lemblklen, outputfile_d);
                //printf("non-exc max_hit_count: %d\n", hit_count);
            }
        }
        else { // when buffer is empty, the initial case
            memcpy(prev_sorted_block, sorted_block, sizeof(double)*block_size);
			prev_sorted_block_size = block_size;
                // copy sorted sample blk  to previous sorted block
            write_multivars(line_samples, lemblklen, outputfile_d); // CDF OUTPUT
            buffered=true; // now we have previous buffer
        }
    }

    // for the last sample data
    write_hit_count(hit_count, outputfile_d); // hit count

    for (int i=0; i<lemblklen; i++) free(line_samples[i]);
    free(line_samples);
    for (int i=0; i<lemblklen; i++)	free(lastline_samples[i]);
    free(lastline_samples);

	return true;
}

bool IDEALEM_SINGLE_STREAM::encoding_with_history() {

// ENCODING with historical buffer
// statistical data reduction for a single stream input from a text file
// 
	int block_size, sorted_block_size;
	int partitionscnt = 0;  // partition cnt to keep track of
	unsigned char partitionsidx;  // partitions index to be written to output file
	bool buffered=false;
	long timestep=0;
	
	double* block_samples = (double*)alloca(sizeof(double)*lemblklen);
    double* sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    LEM_BLOCK* partitions = (LEM_BLOCK*)alloca(sizeof(LEM_BLOCK)*history_buffer);
    for (int i=0; i < history_buffer; i++) {
		partitions[i].block = (double*)alloca(sizeof(double)*lemblklen);
		partitions[i].sorted_block = (double*)alloca(sizeof(double)*lemblklen);
    }

    while ((block_size = read_double(block_samples, lemblklen, inputfile_d)) ) {

        timestep += block_size;
        //printf("timestep: %ld\n", timestep);

        memcpy(sorted_block, block_samples, sizeof(double)*block_size);
		sorted_block_size = block_size;
        qsort(sorted_block, block_size, sizeof(double), compare);
            // sort for a valid input to KStest()
		buffered = false;  // No LEM initially

		if (partitionscnt < history_buffer) {	// when partitions are not populated yet
			for (int i=0; i < partitionscnt; i++) {  // compare with existing partition(s)
	            if (get_exchangeability(sorted_block, block_size, partitions[i].sorted_block, block_size)) {  // exchangeable
						partitionsidx = i;
						// binary output
						// fwrite(&partitionsidx, sizeof(unsigned char), 1, outputfile_enc_d);
						//// text output
	                    write_hit_count(partitionsidx, outputfile_d); // hit count
						buffered = true;
						break; // found LEM, no need to check remaining partition(s)
	            }
			}
			if (!buffered) {  // found no LEM or there's no partition initially
				// above for loop not even executed
				// new singleton partition
				partitionsidx = partitionscnt;
				memcpy(partitions[partitionsidx].block, block_samples, sizeof(double)*block_size); 
				// copy samples to the partition
				memcpy(partitions[partitionsidx].sorted_block, sorted_block, sizeof(double)*block_size); 
				// copy sorted samples to the partition
        
		        // STREAM OUTPUT
				// binary output
		        //fwrite(&partitionsidx, sizeof(unsigned char), 1, outputfile_enc_d);
				// text output
				write_hit_count(partitionsidx, outputfile_d);
		        // CDF OUTPUT
				// binary output
		        // fwrite(partitions[partitionsidx].block, sizeof(double), lemblklen, outputfile_enc_d);
				// text output
				write_double(partitions[partitionsidx].block, lemblklen, outputfile_d); // CDF OUTPUT
				
				partitionscnt++;
	        }
		}
		else { // when partitions are fully populated
			for (int i=0; i < history_buffer; i++) {  // compare with existing partition(s)
				if (get_exchangeability(sorted_block, block_size, partitions[i].sorted_block, block_size)) {  // exchangeable
					partitionsidx = i;
					// binary output
					//fwrite(&partitionsidx, sizeof(unsigned char), 1, outputfile_enc_d);
					// text output
					write_hit_count(partitionsidx, outputfile_d);
					buffered = true;
					break; // found LEM, no need to check remaining partition(s)
				}
			}
			if (!buffered) {  // found no LEM
		        // new singleton partition on rolling basis (oldest partition is overwritten)
		        partitionsidx = 0xFF; // marker signaling overwriting
		        // FILE OUTPUT (overwrite marker)
				// binary output
		        //fwrite(&partitionsidx, sizeof(unsigned char), 1, outputfile_enc_d);
				// text output
				write_hit_count(partitionsidx, outputfile_d);
		        partitionsidx = partitionscnt % history_buffer;
        
		        // Overwriting
		        memcpy(partitions[partitionsidx].block, block_samples, sizeof(double)*block_size); 
				// copy samples to the partition
		        memcpy(partitions[partitionsidx].sorted_block, sorted_block, sizeof(double)*block_size); 
				// copy sorted samples to the partition
				
		        // STREAM OUTPUT
				// binary output
		        // fwrite(&partitionsidx, sizeof(unsigned char), 1, outputfile_enc_d);
				// text output
				write_hit_count(partitionsidx, outputfile_d);
		        // CDF OUTPUT
				// binary output
		        // fwrite(partitions[partitionsidx].block, sizeof(double), lemblklen, outputfile_enc_d);
				// text output
				write_double(partitions[partitionsidx].block, lemblklen, outputfile_d); // CDF OUTPUT
				        
		        partitionscnt++;
			}
		}

    }

	//printf("timestep: %ld\n", timestep);

	return true;
}

bool IDEALEM_SINGLE_STREAM::decoding() {
	//time_t tid;
	long timestep=0;
	double* block_samples = (double*)alloca(sizeof(double)*lemblklen);

    // Intializes random number generator
    //srand((unsigned)time(&tid));
	mycount=0;

    while (read_double(block_samples, lemblklen, inputfile_d)) {
            // read new CDF to fresh buffer until end of the stream
        read_hit_count(inputfile_d);
		//printf("countx=%d\n", hit_count);
        /*
        for (i=0; i < lemblklen; i++)
            printf("%f\n", prevbuffer.blk[i]); // print floating values stored in buffer
         */
        write_double(block_samples, lemblklen, outputfile_d);
            // file output as is for values stored in buffer
        permuted_output(hit_count, block_samples, outputfile_d);
            // output when the stream has repetitions to previous buffers
        timestep += lemblklen * (hit_count+1); // increase timestep

        while (hit_count == max_hit_count) {
            // if hit count equals to max_hit_count
            read_hit_count(inputfile_d); // read again
			//printf("countx=%d\n", hit_count);
            permuted_output(hit_count, block_samples, outputfile_d);
                // output when the stream has repetitions to previous buffers
            timestep += lemblklen*hit_count; // increase timestep
        }
    }
	//printf("TOTAL_COUNT=%d\n", mycount);

	return true;
}

bool IDEALEM_SINGLE_STREAM::decoding_multivars() {
	//time_t tid;

    // Intializes random number generator
    //srand((unsigned)time(NULL));
	//srand((unsigned)time(&tid));
	long timestep=0;
	mycount=0;

    char** line_samples = (char **)malloc(lemblklen * sizeof(char *));
    for (int i=0; i<lemblklen; i++)
		line_samples[i] = (char *)malloc(max_input_read * sizeof(char));
	double* block_samples = (double*)alloca(sizeof(double)*lemblklen);
	
    while (read_double_in_multivars(line_samples, block_samples, lemblklen, inputfile_d)) {
            // read new CDF to fresh buffer until end of the stream
        read_hit_count(inputfile_d);
		//printf("countx=%d\n", hit_count);
        write_multivars(line_samples, lemblklen, outputfile_d);
            // file output as is for values stored in buffer
        permuted_output_in_multivars(hit_count, line_samples, outputfile_d); 
            // output when the stream has repetitions to previous buffers
        timestep += lemblklen * (hit_count+1); // increase timestep

        while (hit_count == max_hit_count) {
            // if hit count equals to max_hit_count
            read_hit_count(inputfile_d); // read again
			//printf("countx=%d\n", hit_count);
            permuted_output_in_multivars(hit_count, line_samples, outputfile_d); 
                // output when the stream has repetitions to previous buffers
            timestep += lemblklen*hit_count; // increase timestep
        }
    }
	//printf("TOTAL_COUNT=%d\n", mycount);

    for (int i=0; i<lemblklen; i++) free(line_samples[i]);
    free(line_samples);
	
	return true;
}

bool IDEALEM_SINGLE_STREAM::decoding_with_history() {
	//time_t tid;
	long timestep=0;
	bool overwrite = false;  // overwrite flag
    unsigned char partitionsidx;  // partitions index to be read from input file
    unsigned char partitionscnt = 0;  
		// partition cnt to keep track of, 
		// no longer increases when it reaches partitionsnum
	LEM_BLOCK* partitions = (LEM_BLOCK*)alloca(sizeof(LEM_BLOCK)*history_buffer);
    for (int i=0; i < history_buffer; i++) {
		partitions[i].block = (double*)alloca(sizeof(double)*lemblklen);
		partitions[i].count = 0;
	}
	
	double* block_samples = (double*)alloca(sizeof(double)*lemblklen);
	hit_count = 0;

    // Intializes random number generator
    //srand((unsigned)time(&tid));
	mycount = 0;

    while (1) {
		if ( !read_hit_count(inputfile_d) ) {
			// printf("end of the input file\n");
			break;
		}
		partitionsidx = hit_count;
		
		if (partitionscnt == history_buffer) { // when partitions are fully populated
			if (overwrite) {
				// read new CDF from CDF FILE and overwrite existing partition
				// binary input
				// fread(partitions[partitionsidx].block, sizeof(double), lemblklen, inputfile_d);  
				// text intput
				read_double(partitions[partitionsidx].block, lemblklen, inputfile_d);
				partitions[partitionsidx].count = 0; // reset counter
				overwrite = false; // reset the flag
			}
			else if (partitionsidx == 0xFF) { // overwriting marker
				overwrite = true;  // raise the flag
				continue; // and continue
			}
		}
		else if (partitionscnt == partitionsidx) { 
			// when partitions are not populated yet and encounters new partition
			// read new CDF from CDF FILE to fresh partition
			// binary input
			// fread(partitions[partitionsidx].block, sizeof(double), lemblklen, inputfile_d);
			// text input
			read_double(partitions[partitionsidx].block, lemblklen, inputfile_d);			
			partitionscnt++;
		}
		
		permuted_output_cdf(partitions, partitionsidx, outputfile_d);
		timestep += lemblklen;
    }
	 
 	//printf("TOTAL_COUNT=%d\n", mycount);

	return true;
}

int IDEALEM_SINGLE_STREAM::read_double(double* ptr, size_t nitems, FILE *stream) {
	int i;
	if (i_type == LEM_IO_BINARY) {
		i = fread((double *)ptr, sizeof(double), nitems, stream);
		mycount+=nitems;
	}
	else {
	    char line[max_input_read];
	    for (i=0; i<nitems; i++) {
	        //if (!fgets(line, sizeof(line), stream)) break;
	        if (fgets(line, max_input_read, stream) == NULL) {
				break;
			}
			mycount++;
			//printf("line=%d=%f\n", mycount, atof(line));
	        *((double*)ptr + i) = atof(line);
	    }
	}
    return i;
}

// mptr : buffer for the line
// ptr : buffer for the variable/column
int IDEALEM_SINGLE_STREAM::read_double_in_multivars(char** mptr, double *ptr, size_t nitems, FILE *stream) {
    int i, jcol;
    char line[max_input_read];
    for (i=0; i<nitems; i++) {
        //if (!fgets(line, sizeof(line), stream)) break;
		if (!fgets(line, max_input_read, stream)) break;
		mycount++;
		((char**)mptr)[i] = strdup(line);	
		jcol=0;
		char* tk=NULL;
		for (char *ti=strtok_r(line, " ,", &tk); ti != NULL; ti=strtok_r(tk, " ,", &tk)) {
			if (jcol == var_column) {
				//printf("%d GOOD ti=%s value=%.10lf : line=%s\n", i, ti, atof(ti), line);
				*((double *)ptr + i) = atof(ti);
			}
			jcol++;
			/*
			char value[max_input_read];
			strcpy(value,"");
			char* tj=strchr(ti,' ');
			if (tj == NULL) strcpy(value, ti);
			else {
				for (; tj!=NULL; tj=strchr(value, ' ')) strcat(value, tj+1);
			}
			*/
		}
    }
    return i;
}

int IDEALEM_SINGLE_STREAM::read_hit_count(FILE *stream) {
	int i;
	if (i_type == LEM_IO_BINARY) {
		//fread((unsigned char *)ptr, sizeof(unsigned char), 1, stream);
		i=fread(&hit_count, sizeof(unsigned char), 1, stream);
	}
	else {
	    char line[max_input_read];
	    if (!fgets(line, sizeof(line), stream)) return 0;
	    hit_count = (unsigned char)atoi(line);
		i = 1;
		//printf("line=%d=%d\n", mycount, atoi(line));
	}
	mycount++;
    return i;
}

int IDEALEM_SINGLE_STREAM::write_double(double *ptr, size_t nitems, FILE *stream) {
	int i;
	if (o_type == LEM_IO_BINARY) {
		i = fwrite((double *)ptr, sizeof(double), nitems, stream);
	}
	else {
	    for (i=0; i<nitems; i++) {
	        //if (!fprintf(stream, "%.8f\n", *(ptr + i)))
	        if (!fprintf(stream, "%.*f\n", precision, *(ptr + i)))
	            break;
	    }
	}
    return i;
}

int IDEALEM_SINGLE_STREAM::write_multivars(char** mptr, size_t nitems, FILE *stream) {
    int i;
    for (i=0; i<nitems; i++) {
		//printf("%d line=%s", i, ((char**)mptr)[i]);
        if (!fprintf(stream, "%s", mptr[i]))	// writing the line buffers
            break;
    }
    return i;
}

int IDEALEM_SINGLE_STREAM::write_a_string(char* mptr, FILE *stream) {
    fprintf(stream, "%s", (char*)mptr);	// writing the string line buffer
    return 1;
}

int IDEALEM_SINGLE_STREAM::write_hit_count(int hcount, FILE *stream) {
	if (o_type == LEM_IO_BINARY) {
		fwrite(&hcount, sizeof(unsigned char), 1, stream);
	}
	else {
		fprintf(stream, "%u\n", hcount);
	}
    return 1;
}

// Print floating values stored in buffer using the permuted sequence 
void IDEALEM_SINGLE_STREAM::permuted_output(int cnt, double* buffer, FILE* outputfile_d) {
    int i;
    int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
	//printf("count=%d\n", cnt);
    while (cnt--) {
        randperm(lemblklen, permsequence); // random shuffle
        for (i=0; i < lemblklen; i++) {
            //printf("%f\n", buffer->blk[perm[i]]); 
                // print floating values using the permuted sequence
            write_double((buffer + permsequence[i]), 1, outputfile_d);
                // file output shuffled for values stored in buffer
        }
    }
    return;
}

void IDEALEM_SINGLE_STREAM::permuted_output_in_multivars(int cnt, char** buffer, FILE* outputfile_d) {
    int i;
	int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
    while (cnt--) {
        randperm(lemblklen, permsequence); // random shuffle
        for (i=0; i < lemblklen; i++) {
			//printf("%d line=%s", i, buffer[permsequence[i]]);
			write_a_string(buffer[permsequence[i]], outputfile_d); 
				// file output shuffled for values stored in buffer
        }
    }

    return;
}

void IDEALEM_SINGLE_STREAM::permuted_output_cdf(LEM_BLOCK* partitions, unsigned char partitionsidx, FILE* outputfile_d) {
    int* permsequence; // permutation sequence for decoding samples
    permsequence = (int*)alloca(sizeof(int)*lemblklen);
	//printf("count=%d\n", cnt);
	if (partitions[partitionsidx].count) { // if this is the repeated use case of lemblk
		randperm(lemblklen, permsequence); // random shuffle
    
		for (int i=0; i < lemblklen; i++) {
			//printf("%f\n", partitions[partitionsidx].block[permsequence[i]]); 
			// print floating values stored in partition
			// binary output
			// fwrite((partitions[partitionsidx].block + permsequence[i]), sizeof(double), 1, outputfile_d); 
			// FILE OUTPUT (values stored in partition)
			// text output
			write_double((partitions[partitionsidx].block + permsequence[i]), 1, outputfile_d); 
		}
	}
	else { // the first use case
		// for (i=0; i < lemblklen; i++) 
			// printf("%f\n", partitions[partitionsidx].block[i]); 
			// print floating values stored in partition
		// binary output
		// fwrite(partitions[partitionsidx].block, sizeof(double), lemblklen, outputfile_d); 
			// FILE OUTPUT AS IS (values stored in partition)
		// text output
		write_double(partitions[partitionsidx].block, lemblklen, outputfile_d); 
		
		partitions[partitionsidx].count++;
	}
	
    return;
}

#else  // C API

bool idealem_exchangeability_single_stream(double* sorted_block, int sorted_block_size, double*prev_sorted_block, int prev_sorted_block_size, double alpha_threshold, unsigned char *hitcount) {
	bool exchangeability_flag=false;
	double kstestprob;  // KS Test return value

	kstestprob=KStest(sorted_block, sorted_block_size, prev_sorted_block, prev_sorted_block_size);
	//printf("kstest=%lf\n", kstestprob);
	if (kstestprob == -1) printf("kstestprob is -1\n");
	if (kstestprob >= alpha_threshold) {  // exchangeable
		(*hitcount)++; 
		exchangeability_flag=true;
	}
	else {
		exchangeability_flag=false;
	}
	//printf("hitcount=%d\n", (int) *hitcount);
    
    return exchangeability_flag;
}


#endif 	// _ENABLE_CXX_IDEALEM
