/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * last updated on Mon Feb 29 15:43:55 PST 2016
 *
 */
//
// idealem_util.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//#include <idealem_const.h>
#include <idealem_common.h>
#include <idealem_util.h>

#ifdef _ENABLE_CXX_IDEALEM
extern "C" {
#endif

// Comparison function. Receives two generic void pointers
int compare(const void *p, const void *q) {
    double x = *(const double *)p;
    double y = *(const double *)q;
    return (x > y) - (x < y);
}

// random permutation
void randperm(int n, int perm[]) {
	time_t tid;
    int i, j, t;
	
    // Intializes random number generator
	srand((unsigned)time(&tid));

    for(i=0; i < n; i++)
        perm[i] = i;

    for(i=0; i < n; i++) {
        j = rand()%(n-i)+i;
        t = perm[j];
        perm[j] = perm[i];
        perm[i] = t;
    }
}

void log_to_file(FILE* logfile_d, char const * str) {
    char buff[32];
    time_t t1 = 0;
    time(&t1);

    struct tm t;
    localtime_r(&t1,&t);
    strftime(buff, 32, "%Y%m%d%H%M%S", &t);

    if ( !logfile_d) {
        printf("couldn't open log file\n");
    }
    else {
        fseek(logfile_d,0,SEEK_END);
        fprintf(logfile_d, "DATE=%s HOST=blank PROG=idealem LVL=Usage SEC=%ld USEC=0 EVNT=%s\n", buff, (long)t1, str);
        fflush(logfile_d);
    }
}

#ifdef _ENABLE_CXX_IDEALEM
}
#endif

