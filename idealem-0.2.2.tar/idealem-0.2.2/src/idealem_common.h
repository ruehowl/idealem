/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University
 * of California, through Lawrence Berkeley National Laboratory (subject to
 * receipt of any required approvals from the U.S. Dept. of Energy).
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software,
 * please contact Berkeley Lab's Innovation & Partnerships Office
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the
 * U.S. Department of Energy.  As such, the U.S. Government has been granted
 * for itself and others acting on its behalf a paid-up, nonexclusive,
 * irrevocable, worldwide license in the Software to reproduce, prepare
 * derivative works, and perform publicly and display publicly.  Beginning
 * five (5) years after the date permission to assert copyright is obtained
 * from the U.S. Department of Energy, and subject to any subsequent five (5)
 * year renewals, the U.S. Government is granted for itself and others acting
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in
 * the Software to reproduce, prepare derivative works, distribute copies to
 * the public, perform publicly and display publicly, and to permit others to
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * Last updated on Mon Thu Mar  3 00:07:41 PST 2016
 *
 */
//
// idealem_common.h
//

#ifndef _IDEALEM_COMMON_H
#define _IDEALEM_COMMON_H

#ifdef _ENABLE_CXX_IDEALEM
extern "C" {
#endif
    typedef struct auxblk {
        double minmintol; // min-(max-min)*reltol
        double minmaxtol; // min+(max-min)*reltol
        double maxmintol; // max-(max-min)*reltol
        double maxmaxtol; // max+(max-min)*reltol
        double width; // max-min
    } AUX_BLOCK;
    
	typedef struct lemblk {
	  double* block; // block holding original sequence samples
	  double* sorted_block; // block holding sorted samples for CDF comparison (used for encoding)
	  int count;	// counter indicating the repeated blocks (used for decoding)
      AUX_BLOCK* aux;
	} LEM_BLOCK;

	enum LEM_IO_TYPE { LEM_IO_TEXT, LEM_IO_BINARY, LEM_IO_ONLINE };
	typedef enum LEM_IO_TYPE  LEM_IO_TYPE_T;

	double KStest(const double* a, int a_size, const double* b, int b_size);
#ifdef _ENABLE_CXX_IDEALEM
}
#endif

#ifdef _ENABLE_CXX_IDEALEM 	// C++ API

class IDEALEM_SINGLE_STREAM {
public:
	IDEALEM_SINGLE_STREAM(int lemblocklen, double alphathreshold, bool encoding=true);
	~IDEALEM_SINGLE_STREAM();

	bool init_for_files(const char* inputfilepath, const char* outputfilepath, LEM_IO_TYPE_T itype, LEM_IO_TYPE_T otype, int maxhitcount=255, int maxinputread=1024, int tprecision=10, int varcolumn=-1, int historybuffer=1);
	bool init_for_files(const char* inputfilepath, const char* outputfilepath, int maxhitcount=255, int maxinputread=1024, int tprecision=10, int varcolumn=-1, int historybuffer=1);
	// encoding default itype=LEM_IO_TEXT, otype=LEM_IO_BINARY
	// decoding default itype=LEM_IO_BINARY, otype=LEM_IO_TEXT

	bool set_inputfile_path(const char* inputfilepath);
	const char* get_inputfile_path();
	bool set_outputfile_path(const char* outputfilepath);
	const char*  get_outputfile_path();
	bool set_logfile_path(const char* logfilepath);
	const char*  get_logfile_path();
	bool isLog();
	bool set_debug(bool debugflag);
	bool isDebug();
	bool isEncoding();
	LEM_IO_TYPE_T set_input_type(LEM_IO_TYPE_T itype);
	LEM_IO_TYPE_T get_input_type();
	LEM_IO_TYPE_T set_output_type(LEM_IO_TYPE_T otype);
	LEM_IO_TYPE_T get_output_type();
	int set_lem_block_size(int lemblocklen);
	int get_lem_block_size();
	double set_alpha_threshold(double alphathreshold);
	double get_alpha_threshold();
	int set_max_hit_count(int maxhitcount);
	int get_max_hit_count();
	int set_max_input_read(int maxinputread);
	int get_max_input_read();
	int set_precision(int tprecision);
	int get_precision();
	int set_var_column(int varcolumn);
	int get_var_column();
	int set_history_buffer(int historybuffer);
	int get_history_buffer();

	bool get_exchangeability(double* sorted_block, int sorted_block_size, double* prev_sorted_block, int prev_sorted_block_size);
	bool encoding();
	bool decoding();
	bool encoding_multivars();
	bool decoding_multivars();
	bool encoding_with_history();
	bool decoding_with_history();

private:
	bool ENCODING_flag;	// default true. DECODING=false
	const char* inputfile_path;
	FILE* inputfile_d;
	const char* outputfile_path;
	FILE* outputfile_d;
	const char* logfile_path;
	FILE* logfile_d;
	bool LOG_flag;		// default=false;
	bool DEBUG_flag;	// default=false;
	int lemblklen;		// default=16;
	double alpha_threshold;	// default=0.05;
	int max_hit_count;		// default=255;
		//     maximum hit count before encoder send out index 
		//     adjusting to smaller value can reduce the delay
	int max_input_read;		// default=1024;
	int precision;		// default=10 
		// decimal precision for floating point or double in writing into output
	int var_column;		// default=-1
	bool multivars;		// default=false
	int history_buffer;	// number of historical buffer
	LEM_IO_TYPE_T i_type;	// input type, encoding: LEM_IO_TEXT decoding: LEM_IO_BINARY
	LEM_IO_TYPE_T o_type;	// output type, encoding: LEM_IO_BINARY decoding: LEM_IO_TEXT

	//char** line_samples;  // sample block array for lines only if varcolumn >= 0
	//char** lastline_samples;  // sample block array for previous lines
	//double* block_samples;
	//double* sorted_block;
	//int sorted_block_size;
	//double* prev_sorted_block; 
	//int prev_sorted_block_size;
	unsigned char hit_count;		// default==0;
        // count to keep track of number of hits 
        // with previous buffer to be written to the output

	int read_double(double* ptr, size_t nitems, FILE *stream);
	int read_double_in_multivars(char** mptr, double* ptr, size_t nitems, FILE *stream);
	int read_hit_count(FILE *stream);
	int write_double(double *ptr, size_t nitems, FILE *stream);
	int write_multivars(char** mptr, size_t nitems, FILE *stream);
	int write_a_string(char *mptr, FILE *stream);
	int write_hit_count(int hcount, FILE *stream);
	void permuted_output(int cnt, double* buffer, FILE* outputfile_d);
	void permuted_output_in_multivars(int cnt, char** buffer, FILE* outputfile_d);
	void permuted_output_cdf(LEM_BLOCK* partitions, unsigned char partitionsidx, FILE* outputfile_d);

	int mycount;

};

#else	// C API
	typedef enum {false, true} bool;
	//#include <stdbool.h>    // for C99
	
	bool idealem_exchangeability_single_stream(double* sorted_block, int sorted_block_size, double*prev_sorted_block, int prev_sorted_block_size, double alpha_threshold, unsigned char *hitcount);

#endif 	// _ENABLE_CXX_IDEALEM

#endif // _IDEALEM_COMMON_H
