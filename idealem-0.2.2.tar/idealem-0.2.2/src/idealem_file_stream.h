/**
 *
 * *** Copyright Notice ***
 *
 * IDEALEM
 * "Implementation of Dynamic Extensible Adaptive Locally Exchangeable 
 * Measures (IDEALEM)"  Copyright (c) 2016, The Regents of the University 
 * of California, through Lawrence Berkeley National Laboratory (subject to 
 * receipt of any required approvals from the U.S. Dept. of Energy).  
 * All rights reserved.
 *
 * If you have questions about your rights to use or distribute this software, 
 * please contact Berkeley Lab's Innovation & Partnerships Office 
 * at IPO@lbl.gov.
 *
 * NOTICE.  This software was developed under funding from the 
 * U.S. Department of Energy.  As such, the U.S. Government has been granted 
 * for itself and others acting on its behalf a paid-up, nonexclusive, 
 * irrevocable, worldwide license in the Software to reproduce, prepare 
 * derivative works, and perform publicly and display publicly.  Beginning 
 * five (5) years after the date permission to assert copyright is obtained 
 * from the U.S. Department of Energy, and subject to any subsequent five (5) 
 * year renewals, the U.S. Government is granted for itself and others acting 
 * on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in 
 * the Software to reproduce, prepare derivative works, distribute copies to 
 * the public, perform publicly and display publicly, and to permit others to 
 * do so.
 *
 */
/**
 *
 * Email questions to SDMSUPPORT@LBL.GOV
 * Scientific Data Management Research Group
 * Lawrence Berkeley National Laboratory
 * http://code.lbl.gov/projects/idealem/
 *
 * last updated on Mon Feb 29 15:42:40 PST 2016
 *
 */
//
// idealem_file_stream.h
//
#ifndef _IDEALEM_FILE_STREAM_H
#define _IDEALEM_FILE_STREAM_H

bool acmp(const char* left, const char* right);

#ifndef _ENABLE_CXX_IDEALEM

int idealem_file_stream_inout(const char* inputfile_path, const char* outputfile_enc_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax, bool widthcheck, double reltol);
// const char* inputfile_path;
// const char* outputfile_enc_path=NULL;
// const char* logfile_path=NULL;
// bool LOG_flag=false;
// bool DEBUG_flag=false;
// int lemblklen=16;
// double alpha_threshold=0.05;
// int max_hit_count=255;
//     maximum hit count before encoder send out index 
//     adjusting to smaller value can reduce the delay
// int max_input_read=1024;
// int prevision=10
// LEM_IO_TYPE_T i_type		default enc=LEM_IO_TEXT 	dec=LEM_IO_BINARY
// LEM_IO_TYPE_T o_type		default enc=LEM_IO_BINARY	dec=LEM_IO_TEXT
	
int idealem_file_stream_inout_multivars(const char* inputfile_path, const char* outputfile_enc_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int colno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type);
// const char* inputfile_path;
// const char* outputfile_enc_path=NULL;
// const char* logfile_path=NULL;
// bool LOG_flag=false;
// bool DEBUG_flag=false;
// int lemblklen=16;
// double alpha_threshold=0.05;
// int max_hit_count=255;
//     maximum hit count before encoder send out index 
//     adjusting to smaller value can reduce the delay
// int max_input_read=1024;
// int colno; // variable column number to compare, based on 0
// LEM_IO_TYPE_T i_type		default enc=LEM_IO_TEXT 	dec=LEM_IO_BINARY
// LEM_IO_TYPE_T o_type		default enc=LEM_IO_BINARY	dec=LEM_IO_TEXT

int idealem_file_stream_inout_with_history(const char* inputfile_path, const char* outputfile_enc_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, int bufferno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax, bool widthcheck, double reltol);
// const char* inputfile_path;
// const char* outputfile_enc_path=NULL;
// const char* logfile_path=NULL;
// bool LOG_flag=false;
// bool DEBUG_flag=false;
// int lemblklen=16;
// double alpha_threshold=0.05;
// int max_hit_count=255;
//     maximum hit count before encoder send out index 
//     adjusting to smaller value can reduce the delay
// int max_input_read=1024;
// int prevision=10;
// int bufferno = 1; 
// 		number of historical buffers
// LEM_IO_TYPE_T i_type		default enc=LEM_IO_TEXT 	dec=LEM_IO_BINARY
// LEM_IO_TYPE_T o_type		default enc=LEM_IO_BINARY	dec=LEM_IO_TEXT

int idealem_file_stream_decoding(const char* inputfile_path, const char* outputfile_dec_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax);
int idealem_file_stream_decoding_multivars(const char* inputfile_path, const char* outputfile_dec_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int colno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type);
int idealem_file_stream_decoding_with_history(const char* inputfile_path, const char* outputfile_dec_path, const char* logfile_path, bool LOG_flag, bool DEBUG_flag, int lemblklen, double alpha_threshold, int max_hit_count, int max_input_read, int precision, int bufferno, LEM_IO_TYPE_T i_type, LEM_IO_TYPE_T o_type, bool delta, bool residual, bool range, double rangemin, double rangemax);

size_t read_double(void *ptr, size_t nitems, FILE *stream, int max_input_read);
size_t read_double_bin(void *ptr, size_t nitems, FILE *stream);
int read_double_in_multivars(void* mptr, int column, void *ptr, size_t nitems, FILE *stream, int max_input_read);
int read_double_in_multivars_bin(void* mptr, int column, void *ptr, size_t nitems, FILE *stream, int max_input_read);
int read_hit_count(void *ptr, size_t nitems, FILE *stream, int max_input_read);
size_t read_hit_count_bin(void *ptr, size_t nitems, FILE *stream);
int write_double(const void *ptr, size_t nitems, FILE *stream, int precision);
size_t write_double_bin(const void *ptr, size_t nitems, FILE *stream);
int write_multivars(const void *mptr, size_t nitems, FILE *stream);
int write_multivars_bin(const void *mptr, size_t nitems, FILE *stream);
int write_a_string(const void *mptr, FILE *stream);
int write_hit_count(const void *ptr, size_t nitems, FILE *stream);
int write_hit_count_bin(const void *ptr, size_t nitems, FILE *stream);
int write_cdf(const LEM_BLOCK* partitions, int nitems, FILE *stream, int partitionscnt, int partitionsnum);

//void permuted_output(int cnt, double* buffer, int perm[], int lemblklen, FILE* outputfile_d);
void permuted_output(int cnt, double* buffer, int lemblklen, FILE* outputfile_d, int precision);
void permuted_output_bin(int cnt, double* buffer, int lemblklen, FILE* outputfile_d);
void permuted_output_in_multivars(int cnt, char** buffer, int lemblklen, FILE* outputfile_d);
void permuted_output_cdf(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d, int precision);
void permuted_output_cdf_bin(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d);
void deltaresidual_output_cdf(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d, int precision, double* valrecover, bool delta, bool range, double rangemin, double rangemax);
void deltaresidual_output_cdf_bin(LEM_BLOCK* partitions, unsigned char partitionsidx, int lemblklen, FILE* outputfile_d, double* valrecover, bool delta, bool range, double rangemin, double rangemax);

#endif // _ENABLE_CXX_IDEALEM

#endif // _IDEALEM_FILE_STREAM_H
